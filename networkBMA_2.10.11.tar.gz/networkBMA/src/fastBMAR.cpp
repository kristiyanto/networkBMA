#include "fastBMA.hpp"
#include <Rcpp.h>
using namespace Rcpp;

// Enable C++11 via this plugin (Rcpp 0.10.3 or later)
// [[Rcpp::plugins(cpp11)]]
// [[Rcpp::export]]
const List fastBMA_g(
		NumericMatrix x,
		int nTimePoints,
		NumericMatrix priorProbs_,
		double oddsRatio,
		double g,
		CharacterVector geneNames,
		int nThreads,
		int geneIndex,
		int optimizeBits,
		int maxOptimizeCycles,
		bool timeSeries,
		bool noPrune,
		double edgeMin,
		double edgeTol) {
  //Rcpp::Rcout << "you got here!\nthe cpp fastBMA_g\n";
  int colNum = x.ncol();
  
	//malloc data********************************************
	double **data = new double*[x.ncol()];
	for (int i = 0; i < x.ncol(); i++) {
		data[i] = new double[x.nrow()];
	}
	for (int i = 0; i < x.ncol(); i++) {
		for (int j = 0; j < x.nrow(); j++) {
			data[i][j] = x(j, i);
		}
	}
	
	/*cerr << "x Data:\n" << x.ncol() << "," << x.nrow() << "\n";
	for (int i = 0; i < x.ncol(); i++) {
		for (int j = 0; j < x.nrow(); j++) {
			cerr << data[i][j] << ", ";
		}
		cerr << endl;
	}*/

	
	//malloc rProbs********************************************
	double **rProbs = new double*[priorProbs_.ncol()];
	for (int i = 0; i < priorProbs_.ncol(); i++) {
		rProbs[i] = new double[priorProbs_.nrow()];
	}
	// change i,j here if vertical
	for (int i = 0; i < priorProbs_.ncol(); i++) {
		for (int j = 0; j < priorProbs_.nrow(); j++) {
			rProbs[i][j] = priorProbs_(j,i);
		}
	}

	
	/*cerr << "priorProbs_ Data:" << priorProbs_.ncol() << "," << priorProbs_.nrow() << "\n";
	for (int i = 0; i < priorProbs_.ncol(); i++) {
		for (int j = 0; j < priorProbs_.nrow(); j++) {
			cerr << rProbs[i][j] << ", ";
		}
		cerr << endl;
	}*/
	

	//new headers********************************************
	vector<string> *headers = new vector<string>();
	for (int i = 0; i < geneNames.size(); i++)
		headers->push_back(as<string>(geneNames[i]));

	/*cout << "headers Data:\n";
	vector<string>::iterator itr = headers->begin();
	for (int i = 0; i < geneNames.size(); i++) {
		cout << *itr << endl;
		itr++;
	}*/
	
	//pre set param
	double uPrior = UNIFORM_PRIOR;
	
	/*err << "flags:" << endl;
	cerr << "nTimePoints: " << nTimePoints << endl;
	cerr << "g: " << g << endl;
	cerr << "optimizeBits: " << optimizeBits << endl;
	cerr << "maxOptimizeCycles: " << maxOptimizeCycles << endl;
	cerr << "uPrior: " << uPrior << endl;
	cerr << "oddsRatio: " << oddsRatio << endl;
	cerr << "nGenes: " << x.ncol() << endl;
	cerr << "nSamples: " << x.nrow() << endl;
	cerr << "nThreads: " << nThreads << endl;
	cerr << "geneIndex: " << geneIndex << endl;
	cerr << "noPrune: " << noPrune << endl;
	cerr << "edgeMin: " << edgeMin << endl;
	cerr << "edgeTol: " << edgeTol << endl;*/

	
	//bool useResiduals = false;
	BMARetStruct *bma_result;
	if(timeSeries) {
		//Rcpp::Rcout << "Time serics call\n";
		bma_result = timeSeriesBMA<double>(
			nTimePoints,
			g, //g
			optimizeBits,
			maxOptimizeCycles,
			uPrior,
			oddsRatio, //oddsRatio
			data, //data
			x.ncol(),//nGenes
			x.nrow(),//nSamples
			&rProbs,//rProbs
			nThreads,//nThreads
			*headers,//headers
			geneIndex,
			noPrune,
			edgeMin,
			edgeTol);
	} else {
		//Rcpp::Rcout << "nonSelf call\n";
		bma_result = nonSelfBMA<double>(
			g, //g
			optimizeBits,
			maxOptimizeCycles,
			uPrior,
			oddsRatio, //oddsRatio
			data, //data
			x.ncol(),//nGenes
			x.nrow(),//nSamples
			&rProbs,//rProbs
			nThreads,//nThreads
			*headers,//headers
			geneIndex,
			noPrune,
			edgeMin,
			edgeTol);
	}
	//cerr << "done c++ call" << endl;
			
/*	template <class T> EdgeList* nonSelfBMA(
			float g, // float gPrior --> float g
			int optimizeBits,
			int maxOptimizeCycles,
			float uPrior,
			float oddsRatio,//oddsRatio
			int nVars,// remove
			string matrixFile,//string matrixFile --> T **data
			int nSamples, // new!
			T ***rProbs,//rProbs
			string priorsListFile,// remove
			int nThreads,
			bool noHeader,//remove
			vector <string> &headers){*/

/*	template <class T> EdgeList* timeSeriesBMA(
			float gPrior,
			int optimizeBits,
			int maxOptimizeCycles,
			float uPrior,
			float oddsRatio,
			int nVars,
			string matrixFile,
			T ***rProbs,
			string priorsListFile,
			int nThreads,
			bool noHeader,
			bool useResiduals, // new param************
			vector<string> &headers){*/


	//cerr << "check point1" << endl;
	//bma_result
	float **edgeWeights = bma_result->edgeWeights;
	int **parents = bma_result->parents;
	int *nParents = bma_result->nParents;
	int nNodes = bma_result->nNodes;
	//cerr << "check point2" << endl;
	int edgeNum = 0;
	for (int i = 0; i < nNodes; i++) {
		edgeNum += nParents[i];
	}
	//cerr << "check point3" << endl;
	//edges
	geneIndex = (geneIndex == -1)?0:geneIndex;
	NumericVector edgeWeightsRet(edgeNum);
	IntegerVector parentsRet(edgeNum);
	IntegerVector nParentsRet(nNodes);
	NumericVector probne0Ret(nNodes);
	//cerr << "check point4" << endl;
	int edgeIndex = 0;
	for (int i = 0; i < nNodes; i++) {
		if (i == geneIndex) {
			for (int j = 0; j < nParents[i]; j++) {
				probne0Ret[parents[i][j]] == edgeWeights[i][j];
			}
		}
		for (int j = 0; j < nParents[i]; j++){
			edgeWeightsRet[edgeIndex] = edgeWeights[i][j];
			parentsRet[edgeIndex] = parents[i][j];
			edgeIndex++;
		}
	}
	//cerr << "check point5" << endl;
	for (int i = 0; i < nNodes; i++)
		nParentsRet[i] = nParents[i];
	//cerr << "check point6" << endl;
	
	List ret;
	ret["edgeWeights"] = edgeWeightsRet;
	ret["nParents"] = nParentsRet;
	ret["parents"] = parentsRet;
	ret["nNodes"] = nNodes;
	ret["probne0"] = probne0Ret;
	//cerr << "check point7" << endl;
	//old return
	int nModels = bma_result->nModels;
	//cerr << "check point8" << endl;
	//cerr << "nModels: " << nModels << endl;
	NumericVector postprobsRet(nModels);
	//cerr << "check point8.1" << endl;
	double *postprobs = bma_result->postProbs;
	//cerr << "check point8.2" << endl;
	for (int i = 0; i < nModels; i++) {
		postprobsRet[i] = postprobs[i];
	}
	//cerr << "check point9" << endl;
	NumericVector r2sRet(nModels);
	double *r2s = bma_result->r2s;
	for (int i = 0; i < nModels; i++) {
		r2sRet[i] = r2s[i];
	}
	//cerr << "check point10" << endl;
    NumericVector bicsRet(nModels);
	double *bics = bma_result->bics;
	for (int i = 0; i < nModels; i++) {
		bicsRet[i] = bics[i];
	}
	//cerr << "check point11" << endl;
	IntegerVector sizeRet(nModels);
	int *size = bma_result->size;
	for (int i = 0; i < nModels; i++) {
		sizeRet[i] = size[i];
	}
	//cerr << "check point12" << endl;
	IntegerMatrix indicesMatrix(nModels, colNum);
	int **whichMatrix = bma_result->whichMatrix;
	for (int i = 0; i < nModels; i++) {
		for (int j = 0; j < colNum; j++) {
			indicesMatrix(i, j) = whichMatrix[i][j];
		}
	}
/*	class BMARetStruct {
public:

	//edges
	float **edgeWeights;
	int *nParents, **parents, nNodes;
	
	//old BMA return
	float *r2s, *bics, *postProbs;
	int nModels, checkedModels, *size, **whichMatrix;
};*/
	//cerr << "check point13" << endl;
	ret["postprob"] = postprobsRet;//
	ret["r2"] = r2sRet;//
	ret["bic"] = bicsRet;//
	ret["size"] = sizeRet;//
	ret["which"] = indicesMatrix;//
	ret["reduced"] = !noPrune;//
	ret["n.models"] = nModels;//
	ret["nmodelschecked"] = bma_result->checkedModels;//
	//cerr << "check point14" << endl;
	//free data********************************************
	/*for (int i = 0; i < x.nrow(); i++) {
		free(data[i]);
	}
	free(data);

	//free rProbs********************************************
	for (int i = 0; i < x.nrow(); i++) {
		free(rProbs[i]);
	}
	free(rProbs);

	delete(headers);*/

	return ret;

}
