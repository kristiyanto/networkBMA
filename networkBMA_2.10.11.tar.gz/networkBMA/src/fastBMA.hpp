#include <iostream>
#include <set>
#include <map>
#include <limits>
#include "my_sort.hpp"
#include <unordered_set>
#include "OpenBLAS/cblas.h"
#include <omp.h>
#include <time.h>
#include <inttypes.h>
#include <vector>
#include <algorithm>
#include <queue>
#include <boost/math/tools/minima.hpp>
#include <fstream>
#include <sstream>
#include <unordered_map>
#define UNIFORM_PRIOR 2.76/6000.0;

using namespace std;
//using namespace std::tr1;
float edgeTol=-1;
float edgeMin=.5;
bool noPrune=0;

//utils
template <class T> void print_array(T* array,int n,int stride);
template <class T> void print_array(T* array,int n,int stride,char *format);


//timers
bool gtime=0;


//set up for timeSeries
template <class T> T TimeSeriesValuesToResiduals(T *values, T *residuals,int nTimes,int nGroups);


//class definitions
//DenseTrMatrix stores an upper triangular matrix to save room for storage of models
//The Indices classes take advantage of the fact that our set of variables is always limited in size and that this is known beforehand
//So at a minor cost in memory we can avoid a linked list
//Instead we have a list that stores the indices and an index array that points to the location in the list where an index resides
//ie. list[index[model]-1]=model (zero is reserved to indicate that a model is not in the list so we add 1 to the locations when we store them in the index array)
//The basic implementation is the ModelIndices class for this
//CompactModelIndices eliminates the index altogether. Presently we don't need random access to the list except during insert deletion so this saves the memory cost of the index - important for the hash which keeps track of all the modelsets that have been evaluated
//A bitArray index is generated when needed to compare two sets of indices as needed
//memory could be further reduced by templating the indices to allow for char and short unsigned int indices (256 and 64K limit) or using a bitarray to store the elements which would also be faster. Alternatively use a suffix array to store the model sets similar to what is done for short read sequencing. For maintaining a list of very large sets  that would probably be the best way to go instead of the current hash system


//some definitions needed for Dijkstra
//add early abort if the route is already worse than the existing route
class Comparator{
 public:
 int operator() ( const pair<int,float>& p1, const pair<int,float> &p2)
 {
 return p1.second>p2.second;
 }
};

class BitIndex{
	//simple class meant for throwaway comparisons
 unsigned char *bitArray; //unsigned because the behavior of negative bit may not be well defined
 int minValue;
 int maxValue;
 public:
 BitIndex(int *list,int nModels){
		maxValue=list[0];
		minValue=list[0];
		for(int i=1;i<nModels;i++){
			if(list[i] > maxValue)maxValue=list[i];
			if(list[i] < minValue)minValue=list[i];
		}	
		const int range=maxValue-minValue;
	 size_t arraySize=(range/8)+1;
		bitArray=new unsigned char[arraySize];
		memset (bitArray,0,arraySize);
	 for(int i=0;i<nModels;i++){ 
	  setBit(list[i]-minValue);
		} 
	}
	bool compare(int *list,int nModels){
	 for(int i=0;i<nModels;i++){
			if(list[i]<minValue || list[i] > maxValue || !getBit(list[i]-minValue)){
			 return(0);
			}
		}						
		return(1);
	} 
	unsigned char getBit(int index) {
  return (bitArray[index/8] >> 7-(index & 0x7)) & 0x1;
 }
 unsigned char setBit(int index) {
  bitArray[index/8] = bitArray[index/8] |  1 << 7-(index & 0x7);
 }
 ~BitIndex(){
  delete [] bitArray; 
	}
		
};
template <class T>class DenseTrMatrix{
	//includes diagonal - single block of numbers - optimized for upper diagonal column major (FORTRAN style) access
	//not used for optimization but for storage requirements
 public:
 T *matrix;     //matrix
 int size; //number rows or columns 
 DenseTrMatrix(){
  matrix=0;
  size=0;
	}
 DenseTrMatrix(int m){
  matrix=new T [m*(m+1)/2];
  size=m;
	}		
	DenseTrMatrix(const DenseTrMatrix  &A){
	 size=A.size;
	 if(size){
	  matrix=new T [size*(size+1)/2];
   memmove(matrix,A.matrix,size*(size+1)/2*sizeof(T));
		}
		else{
			matrix=0;
		}	 
	}
 DenseTrMatrix & operator = (const DenseTrMatrix &rhs){	 
		if(rhs.size ==0){
		 if(size) delete [] matrix;
		 matrix=0;
		 size=0;
		}
		else if(rhs.size != size){
			if(size) delete [] matrix;
			size=rhs.size;
	  matrix=new T [size*(size+1)/2];
   memmove(matrix,rhs.matrix,size*(size+1)/2*sizeof(T));
		}
		else{
			memmove(matrix,rhs.matrix,size*(size+1)/2*sizeof(T));
		}	
	}
 void sq_to_tr(T *sqmatrix, int ldn)const{
		//leading dimension size provided - dense storage
		//upper column major expected
	 T *s=matrix;
	 size_t inc=sizeof(T);
	 size_t blocksize=inc;
	 for (int i=1;i<=size;i++){
			memmove(s,sqmatrix,blocksize);
			blocksize+=inc;
			s+=i;
			sqmatrix+=ldn;
		}	
	}
	void tr_to_sq (T *sqmatrix,int ldn)const{
		//leading dimension size provided - dense storage
		//upper column major expected
  //copies whol matrix
	 T *s=matrix;
	 size_t inc=sizeof(T);
	 size_t blocksize=sizeof(T);
	 for (int i=1;i<=size;i++){
			memmove(sqmatrix,s,blocksize);
			blocksize+=inc;
			s+=i;
			sqmatrix+=ldn;
		}	
	}
	void tr_to_sq_delj (T *d, int ldn,int j)const{
		//remove jth column
	 T *s=matrix;
	 size_t inc=sizeof(T);
	 size_t blocksize=inc;
	 int i=1;
	 while(i<=j){
			memmove(d,s,blocksize);
   blocksize+=inc;
			d+=ldn;
			s+=i;
			i++;
		}
		blocksize+=inc;
		s+=i;
		i++;	
	 while(i<=size){
			memmove(d,s,blocksize);
   blocksize+=inc;
			d+=ldn;
			s+=i;
			i++;
		}
	}
 void print()const{
	const int n=size*(size+1)/2;
	for(int row=0;row<size;row++){
  for(int col=0;col<row;col++){
			cout << 0 <<'\t';
		}
		int k=(row+1)*(row+2)/2-1;
		for(int col=row;col<size;col++){
		 cout << matrix[k] <<'\t';
		 k+=col+1;
		}
		cout <<endl; 
	}
	cout << endl;	
}	 
	~DenseTrMatrix(){
		if(matrix){
			delete[] matrix;
		}	
	}	
};
class ModelIndices{
	//unordered list of indices of models - can add and delete
	//save room in list for this - allocates maxModel space instead of nModel space
	public:
 	int maxModels;
 	int nModels;
 	int *index;
 	int *list;
 	unsigned int hashValue;
 	ModelIndices(){
			maxModels=0;
			nModels=0;
			index=0;
			list=0;
			hashValue=0;
		}
		ModelIndices(int h){
			maxModels=h;
			index=new int[maxModels];
			memset(index,0,maxModels*sizeof(int));
			list=new int[maxModels];			
			nModels=0;
			hashValue=0;
		}
		ModelIndices(const ModelIndices &A): maxModels(A.maxModels),nModels(A.nModels),hashValue(A.hashValue){
			//doesn't copy any of the gunk that might be at the end of the list array
			index=new int[maxModels];
			list=new int[maxModels];
			memmove(index,A.index,maxModels*sizeof(int));
			memmove(list,A.list,maxModels*sizeof(int));
  }

  //full copy done when ModelIndices copied to modelIndices
   ModelIndices & operator = (const ModelIndices &rhs){
				if(!rhs.maxModels){
				//reset
				maxModels=0;
			 nModels=0;
			 if(index)delete[]  index;
			 if(list)delete[] list;
			 index=0;
			 list=0;
			}	
			else{
				if(maxModels != rhs.maxModels){
					if(maxModels){
						delete[] index;
						delete [] list;
					}
					maxModels=rhs.maxModels;
					index=new int[maxModels];	
					list=new int[maxModels];	
				}
				nModels=rhs.nModels;
    memmove(index,rhs.index,maxModels*sizeof(int));
    if(nModels) memmove(list,rhs.list,nModels*sizeof(int));
			}
			hashValue=rhs.hashValue;
		}
		void insertElement(int m){ 
			if(!index[m]){
			 list[nModels++]=m;  //add to end of list - we *want* nModels to be incremented before assignment
	   index[m]=nModels;	  //put a pointer to where the index is for deletion. This is incremented by 1 so that zero can indicate non-membership
			}
			unsigned int h= ((m >> 16) ^ m) * 0x45d9f3b;
   h = ((h >> 16) ^ h) * 0x45d9f3b;
   h = ((h >> 16) ^ h);
		 hashValue= hashValue ^h;
		}
		int deleteElement_unordered(int m){
			//switches element with last element of list for quick removal
			//is not necessarily the same order as the variables in the R matrix
			//useful for hashing to see if set has been seen
			if(nModels){
			 int i=index[m]-1; //index to be deleted
			 if(i >=0){
					index[m]=0;
			 	if(i != nModels-1){
			 		const int oldm=list[nModels-1];
			 		list[i]=oldm;
			 		index[oldm]=i+1;
			 	}
					nModels--;
			 }
			 unsigned int h= ((m >> 16) ^ m) * 0x45d9f3b;
    h = ((h >> 16) ^ h) * 0x45d9f3b;
    h = ((h >> 16) ^ h);
		  hashValue= hashValue ^h;
			 return(i);
			}
			hashValue=0;
   return(0);
		}
		int deleteElement(int m){
			//contracts list
			//keeps list in same order as variables in matrix
			if(nModels){
			 int i=index[m]-1; //index to be deleted
			 index[m]=0;
			 for(int k=i+1;k<nModels;k++){
			  list[k-1]=list[k];
			  index[list[k]]=k;
			 }	
			 nModels--;
			}
			return(0);
		}
		int order_deletion(int i){
			//converts an unordered deletion to one that matches R
			//need to know the ith column
			int temp=list[i];
			for(int k=i+1;k<nModels;k++){
			 list[k-1]=list[k];
			 index[list[k]]=k;
			}
			list[nModels-1]=temp;
			index[temp]=nModels; //add to index...
		}
		bool operator==(const ModelIndices &b)const{
	 if(nModels != b.nModels || hashValue != b.hashValue)return(0);
	 if(nModels==0)return(1);
  for (int i=0;i<nModels;i++){
			if(!b.index[list[i]])return(0);
		}
  return(1);	
	}
	 void print_list()const{
		for(int i=0;i<nModels;i++){
		 cout << i << '\t' << list[i] << '\t' << index[list[i]]-1 <<endl;
		}
	}
		~ModelIndices(){
			if(maxModels){
		  if(index)delete [] index;
		  if(list)delete [] list;
			}
		}			 
};
class CompactModelIndices{
	//only stores the minimum amount of information needed to distinguish between indices
 //for speed a bit array is used (more likely to fit in cache);
	public:
 	int nModels;
 	int *list;
 	unsigned int hashValue;
 	CompactModelIndices(){
			nModels=0;
			list=0;
			hashValue=0;
		}		
		CompactModelIndices(int n){
			if(n)list=new int[n];			
			nModels=n;
			hashValue=0;
		}				
		CompactModelIndices(ModelIndices &mind){
			nModels=mind.nModels;
			list=new int[nModels];			
   memmove(list,mind.list,nModels*sizeof(int));
   hashValue=mind.hashValue;
		}			
		CompactModelIndices(const CompactModelIndices &A):nModels(A.nModels){
			//doesn't copy any of the gunk that might be at the end of the list array
			if(nModels){
			 list=new int[nModels];
			 memmove(list,A.list,nModels*sizeof(int));
			}
			else{
			 nModels=0;
			 list=0;
			}
			hashValue=A.hashValue;	
  }
  CompactModelIndices & operator = (const ModelIndices &rhs){
			if(!rhs.nModels){
				//reset
			 nModels=0;
			 if(list)delete[] list;
			 list=0;
			}	
			else{
				if(nModels != 	rhs.nModels){
					if(nModels){
						delete [] list;
					}
					nModels	=rhs.nModels;
					if(nModels){
					 list=new int[nModels];
					 memmove(list,rhs.list,nModels*sizeof(int));
					}
				}
				nModels=rhs.nModels;
    if(nModels) memmove(list,rhs.list,nModels*sizeof(int));
			}
			hashValue=rhs.hashValue;
  }

  CompactModelIndices & operator = (const CompactModelIndices &rhs){
			if(!rhs.nModels){
				//reset
			 nModels=0;
			 if(list)delete[] list;
			 list=0;
			}	
			else{
				if(nModels != 	rhs.nModels){
					if(nModels){
						delete [] list;
					}
					nModels	=rhs.nModels;
					if(nModels){
					 list=new int[nModels];
					 memmove(list,rhs.list,nModels*sizeof(int));
					}
				}
				nModels=rhs.nModels;
    if(nModels) memmove(list,rhs.list,nModels*sizeof(int));
			}
			hashValue=rhs.hashValue;
  }

		bool operator==(const ModelIndices &b)const{
	  if(nModels != b.nModels || hashValue != b.hashValue )return(0);
	  if(nModels==0)return(1);
   for (int i=0;i<nModels;i++){
		 	if(!b.index[list[i]])return(0);
		 }
   return(1);	
	 }	
	 bool operator==(const CompactModelIndices &b)const{
			//create index on the fly

	  if(nModels != b.nModels || hashValue != b.hashValue)return(0);
	  if(nModels==0)return(1);
	  BitIndex bitIndex (list,nModels);
   return(bitIndex.compare(b.list,b.nModels));
		}
	 void print_list()const{
		for(int i=0;i<nModels;i++){
		 cout << i << '\t' << list[i]<<endl;
		}
	}		
		~CompactModelIndices(){
			if(nModels) delete [] list;
		}		
};	
namespace std {
		template <> 
		struct hash <CompactModelIndices>{
   std::size_t operator()(const CompactModelIndices& k) const
   {
				
				if(!k.hashValue){
					unsigned int hash=0;;
		  //pairwise XOR each element
		   for (int i=0;i<k.nModels;i++){
		 			unsigned int h =k.list[i];
					//for 64 bit machines murmurhash3
					/*
				 	h ^= h >> 33;
      h *= 0xff51afd7ed558ccd;
      h ^= h >> 33;
      h *= 0xc4ceb9fe1a85ec53;
      h ^= h >> 33;
     */
//    use as default 32 bit compatibility     
 			 	h = ((h >> 16) ^ h) * 0x45d9f3b;
      h = ((h >> 16) ^ h) * 0x45d9f3b;
      h = ((h >> 16) ^ h);
      hash=hash ^ h;
		   }
		   return(hash);
			 }
			 return(k.hashValue);    
	 	}
  }; 
}

template <class T> class ModelSet{
	public:
	CompactModelIndices modelIndices;
	T r2;
	T bic;
	double logprior;
 DenseTrMatrix <T> R;
 ModelSet() {
   modelIndices =0;
   r2 =0;
   bic =0;
   logprior=0;
   R=DenseTrMatrix<T>();
 };
 ModelSet( ModelIndices mInd, T mr2, T mbic, double mlogprior) {
   modelIndices = mInd;
   r2 = mr2;
   bic = mbic;
   logprior=mlogprior;
   R=DenseTrMatrix<T>();
 };
 ModelSet( CompactModelIndices mInd, T mr2, T mbic,double mlogprior ) {
  modelIndices = mInd;
  r2 = mr2;
  bic = mbic;
  logprior=mlogprior;
  R=DenseTrMatrix<T>();
 };
 ModelSet( ModelIndices mInd, T mr2, T mbic,double mlogprior, T *sqR, int nRows,int ldn) {
   modelIndices = mInd;
   r2 = mr2;
   bic = mbic;
   R=DenseTrMatrix<T>(nRows);
   R.sq_to_tr (sqR,ldn);
   logprior=mlogprior;
 };

 ModelSet( CompactModelIndices mInd, T mr2, T mbic,double mlogprior,T *sqR, int nRows,int ldn) {
  modelIndices = mInd;
  r2 = mr2;
  bic = mbic;   
  R=DenseTrMatrix<T>(nRows);
  R.sq_to_tr (sqR,ldn);
  logprior=mlogprior;
 };
	ModelSet (const ModelSet &A){
	 R=A.R;
	 modelIndices=A.modelIndices;				
  bic=A.bic;
		r2=A.r2;   
	 logprior=A.logprior; 
 }
 ModelSet & operator = (const ModelSet &rhs){
				//deep copy of R
  R=rhs.R;
		bic=rhs.bic;
		r2=rhs.r2; 
		modelIndices=rhs.modelIndices;
		logprior=rhs.logprior; 	
	}
	bool operator<(const ModelSet& b) const { return bic < b.bic; }
 bool operator>(const ModelSet& b) const { return bic > b.bic; }
 bool operator>=(const ModelSet& b) const { return !(*this < b); }
 bool operator<=(const ModelSet& b) const { return !(*this > b); }
	bool operator==(const ModelSet &b)const{
		return(modelIndices == b.modelIndices);
	}
	bool operator!=(const ModelSet& b) const { return !(*this == b); }
};




//for sorting by edgeweights we need data structure where there is a pair and a score
//simple edge list class with weights and sort routine
class EdgeList{
	public:
 int **parents;
 float **edgeWeights;
 int *nParents;
 int nNodes;
 EdgeList(){
		nNodes=0;parents=0;nParents=0;edgeWeights=0;
	}	
 EdgeList(int n){
		nNodes=n;
		parents=new int*[n];
		nParents=new int[n];
		edgeWeights=new float*[n];
		for (int i=0;i<n;i++){
			parents[i]=0;
			nParents[i]=0;
			edgeWeights[i]=0;
		}
	} 
	EdgeList(const EdgeList &A){
		nNodes=A.nNodes;
		parents=new int*[nNodes];
		nParents=new int[nNodes];
		edgeWeights=new float*[nNodes];
		memmove(nParents,A.nParents,nNodes*sizeof(int));
		for (int i=0;i<nNodes;i++){
			if(nParents[i]){
				parents[i]=new int[nParents[i]*sizeof(int)];
				memmove(parents[i],A.parents[i],nParents[i]*sizeof(int));
				edgeWeights[i]=new float[nParents[i]*sizeof(float)];
				memmove(edgeWeights[i],A.edgeWeights[i],nParents[i]*sizeof(float));	 
			}	
			else{
			 parents[i]=0;
			 nParents[i]=0;
			 edgeWeights[i]=0;
			}
		}	
	}

 ~EdgeList(){
		for (int i=0;i<nNodes;i++){
			if(nParents){
				delete[] parents[i];
				delete[] edgeWeights[i];
			}	
		}
		if(nNodes){
			delete[] nParents;delete[] edgeWeights;delete[] parents;
		}		
	}
	void printEdges(float edgeMin,vector<string> headings,bool selfie,bool keepNegative){
		for(int i=0;i<nNodes;i++){
			for (int j=0;j<nParents[i];j++){
				if((selfie || parents[i][j] != i) && (edgeWeights[i][j] >= edgeMin || (keepNegative && -edgeWeights[i][j] >= edgeMin))){
					if(headings.size()){
						cout << headings[parents[i][j]] << '\t' << headings[i]<< '\t' << edgeWeights[i][j] <<endl;
					}
					else{
						cout << parents[i][j] << '\t' << i << '\t' << edgeWeights[i][j] <<endl;	
					}
				}
			} 
		}	
	}
	void printEdges(float edgeMin,vector <string>headings,float *adjMatrix,bool selfie){
		for(int i=0;i<nNodes;i++){
			float* const slice=adjMatrix+i*nNodes;
		 for (int j=0;j<nParents[i];j++){
			 if((selfie || parents[i][j] != i) && edgeWeights[i][j] >= edgeMin && slice[j] < 2.0f){
					if(headings.size()){
			   cout << headings[parents[i][j]] << '\t' << headings[i]<< '\t' << edgeWeights[i][j] <<endl;
					}
					else{
					cout << parents[i][j] << '\t' << i << '\t' << edgeWeights[i][j] <<endl;	
					}	
			 }
			} 
		}	
	}
	float* convert_to_pvalue_matrix(){
  float *adjMatrix=new float[nNodes*nNodes];
  for(int i=0;i<nNodes*nNodes;i++){
			adjMatrix[i]=0; //indicates noEdge
		}	
		for(int i=0;i<nNodes;i++){
		 for (int j=0;j<nParents[i];j++){
			 adjMatrix[parents[i][j]*nNodes+i]=edgeWeights[i][j];
			}
		}
		return(adjMatrix);			
	}
		
	float** convert_to_logodds(){
		float **logWeights=new float* [nNodes];		
	 for(int i=0;i<nNodes;i++){
			if(nParents[i]){
				logWeights[i]=new float[nParents[i]];
			}
			else logWeights[i]=0;	
		 for (int j=0;j<nParents[i];j++){
				if(edgeWeights[i][j]){
		 	 logWeights[i][j]=-log(edgeWeights[i][j]);
		 	 logWeights[i][j]=(logWeights[i][j] <0)? 0 : logWeights[i][j];
				} 
		 	else
		 	 logWeights[i][j]=0; 
   }
	 }
	 return(logWeights);
	}
	
float dijkstra_limit(const int source,const int destination,const float limit, float **logWeights, float tol){
 float *d=new float[nNodes];
 int path_found=0;
 for(int i = 0 ;i < nNodes; i++){
  d[i] = std::numeric_limits<float>::max();
 }
 priority_queue<pair<int,float>, vector<pair<int,float> >, Comparator> Q;
 d[destination] = 0.0f; //semantics - we start at the destination and work backwards to the source
 Q.push(make_pair(destination,d[destination]));
 while(!Q.empty()){
  int u = Q.top().first;
  if(u==source){ 
			path_found=1;
			break; //found shortest path
		}
  Q.pop();

  for(unsigned int i=0; i < nParents[u]; i++){
			if(logWeights[u][i] >=0){ //less than 0 indicates edge has been deleted
    const int v= parents[u][i];
    if ((u!=destination || v != source) && u != v){
     const float w = logWeights[u][i];
     if(d[v] > d[u]+w){
      d[v] = d[u]+w;
      if(d[v] <= limit +tol ){ //don't push parents onto queue unless the path is still <= the confidence of "direct" path and the edge not the direct path
       Q.push(make_pair(v,d[v]));
		  		}
     }
			 }
			} 
  }
 }
 if (!Q.empty()){
		return(d[Q.top().first]);
	}
	else{ 
	 return (-1);
	}	
 delete[] d;
}

 pair<int,int>* sort_by_edge_weights(float **logWeights,int *nEdges,float edgeMin){
	 //returns a sorted array of pairs node - parent_index
	 //returns the logWeights
	 int my_nEdges=0;	
	 for(int i=0;i<nNodes;i++){
	 	for (int j=0;j<nParents[i];j++){
	  	if(edgeWeights[i][j] > edgeMin) my_nEdges++;
			}
		}
	 pair <int,int> *nodeParent=new pair<int,int>[my_nEdges];	 
	 pair <int,int> *temp=new pair<int,int>[my_nEdges];
	 int *sortIndex=new int[my_nEdges];
	 float *scores=new float[my_nEdges];
	 int n=0;
  for (int i=0;i<nNodes;i++){
		 for (int j=0;j<nParents[i];j++){
		 	if(edgeWeights[i][j] > edgeMin){
		 	 temp[n].first=i;
		 	 temp[n].second=j;
		 	 scores[n++]=logWeights[i][j];
			 }
		 }
	 }
	 sort_by_scores(my_nEdges,scores,sortIndex,0);
	 for	(int i=0;i<my_nEdges;i++){
			nodeParent[i]=temp[sortIndex[i]];
		}
		delete[] temp;
		delete[] scores;
		*nEdges=my_nEdges;
		return(nodeParent);		
 }

	int prune_edges(float edgeMin,float edgeTol){
		//if(edgeMin) removePoorEdges(edgeMin);
		float **logWeights=convert_to_logodds();

		int nEdges=0;
		pair<int,int> *nodeParent= sort_by_edge_weights(logWeights,&nEdges,edgeMin);
		
		for(int i=0;i<nEdges;i++){
		 const int endNode=nodeParent[i].first;
		 const int j=nodeParent[i].second;
		 const float limit=logWeights[endNode][j];			 
		 float tol=(edgeTol >=0) ? log((double)(1.0) + (double) edgeTol) : 0;
			const float retvalue=dijkstra_limit(parents[endNode][j],endNode,limit,logWeights,tol);
			if(retvalue != -1){
			 //just set the i j of logWeights <0 to mark this - simpler than updating all the sizes
			 logWeights[endNode][j]=-1;
			}
				
		}
		for(int i=0;i<nEdges;i++){
			const int endNode=nodeParent[i].first;
		 const int j=nodeParent[i].second;
		 if(logWeights[endNode][j]<0)edgeWeights[endNode][j]=-edgeWeights[endNode][j];
		}
	}
	float* cutter_prune_edges(float lower_threshold,float upper_threshold){
		//negative numbers are indicated for deletion in multithread
	 float *adjMatrix=convert_to_pvalue_matrix();
	 for (int k = 0; k < nNodes; k++){
			int m=0;
			float* const slicek=adjMatrix+k*nNodes;
		 for (int i = 0; i <nNodes; i++){
				float* const slicei=adjMatrix+i*nNodes;
			 for (int j = 0; j < nNodes; j++){
				 const float edge = 1.0f-adjMatrix[m];
				 if (edge<lower_threshold){
					 float viaK =  fmaxf(fabsf(slicei[k]), fabsf(slicek[j]) );
					 if ( fabsf(edge) > viaK ){
						 slicei[j] = -viaK;
					 }
					}
					m++;
				}
			}
		}
	 for (int i = 0; i < nNodes*nNodes; i++){
		 float val = adjMatrix[i];
		 if (((*((unsigned int*)&val) & 2147483648u))   or   (val >= upper_threshold)  )adjMatrix[i] = 2.0f;
	 }
	 return(adjMatrix);
	}
};

/********************** Kaiyuan *********************/
class BestModelRet {
public:
    double retvalue;
	double *r2s, *bics, *old_postProbs;
	int nModels, nmodelschecked, *size, **whichMatrix;
};
/********************** Kaiyuan *********************/
class FastScanBMAgRet {
public:
	double *r2s, *bics, *old_postProbs;
	int nModels, nmodelschecked, npostProbs, *size, **whichMatrix;
};
/********************** Kaiyuan *********************/
class BMARetStruct {
public:

	//edges
	float **edgeWeights;
	int *nParents, **parents, nNodes;
	
	//old BMA return
	double *r2s, *bics, *postProbs;
	int nModels, checkedModels, *size, **whichMatrix;
};

	
//main subroutines
//template <class T> BMARetStruct* timeSeriesBMA(float gPrior,int optimizeBits,int maxOptimizeCycles,float uPrior,float oddsRatio,int nVars,string matrixFile,T **rProbs,string priorsListFile,int nThreads, bool noHeader,bool useResiduals, vector <string> &headers);
template <class T> BMARetStruct* timeSeriesBMA(int nTimePoints, float gPrior,int optimizeBits,int maxOptimizeCycles,float uPrior,float oddsRatio,T **data,int nGenes,int nSamples,T ***rProbs,int nThreads, vector <string> &headers, int geneIndex, bool noPrune, float edgeMin, float edgeTol);
//template <class T> BMARetStruct* nonSelfBMA(float gPrior,int optimizeBits,int maxOptimizeCycles,float uPrior,float oddsRatio,int nVars,string matrixFile,T ***rProbs,string priorsListFile,int nThreads, bool noHeader,vector <string> &headers);
template <class T> BMARetStruct* nonSelfBMA(float gPrior,int optimizeBits,int maxOptimizeCycles,float uPrior,float oddsRatio,T **data,int nGenes,int nSamples,T ***rProbs,int nThreads,vector <string> &headers, int geneIndex, bool noPrune, float edgeMin, float edgeTol);
template <class T> T** readPriorsMatrix(string priorsFile);
template <class T> void readPriorsList(string priorsListFile,vector <string> names, T **priors, T uniform_prob);
EdgeList* readEdgeListFile (string edgeListFile,vector<string> &names);
//scanBMA with g prior
//template <class T> int fastScanBMA_g(T *mATA, T *mATb,T btb,T sst, int ignoreIndex, T *priorProbs,double *postProbs,int *parents, int nRows, int nCols, int nVars, double logOR ,double g, int optimizeBits,int maxOptimizeCycles);
template <class T> FastScanBMAgRet* fastScanBMA_g(T *mATA, T *mATb,T btb,T sst, int ignoreIndex, T *priorProbs,double *postProbs,int *parents, int nRows, int nCols, int nVars, double logOR ,double g, int optimizeBits,int maxOptimizeCycles);


//routine for choosing best sets of models - repeated multiple times to optimize for parameters
//template <class T> T chooseBestModels(double g,T *ATA,int nVars,int nRows,int nCols,int *pord,T *ATb,T sst, T btb, double *postProbs, int *parents, int *npostProbs, double *logpriors,double logOR);
template <class T> BestModelRet* chooseBestModels(double g,T *ATA,int nVars,int nRows,int nCols,int *pord,T *ATb,T sst, T btb, double *postProbs, int *parents, int *npostProbs, double *logpriors,double logOR, BestModelRet* theModelRet);

//calculate the sst
template <class T> T calculate_sst(int sizeb, T *b,T *ones);

//needed for copying - overloading = requires both classes to be defined - no easy way to predefine classes
void copy_indices(ModelIndices &dest,const CompactModelIndices  &source);

//cholesky routines to calculate correlation coeff
template <class T> T getR2_full(ModelIndices &modelIndices,T* ATA,int ATAldr, T* ATb,const T btb,T *R,int Rldr);
template <class T> T getR2_down(int nRows,ModelIndices &modelIndices,T* ATb,const T btb,T *R, int Rldr, int dCol);
template <class T> T getR2_up(ModelIndices &modelIndices,T* ATA,int ATAldr, T* ATb,const T btb,T *R,int Rldr);

//givens rotation on columns for Cholesky downdate
template <class T> void qhqr (int nRows,int nCols,T *R, int ldr,T *c,T *s);

//LAPACK FORTRAN subroutines needed for givens - drotg is too inaccurate - 
extern "C"{
 extern void dlartg_ ( double* f, double* g, double* cs, double* sn, double* r );
 extern void slartg_ ( float* f, float* g, float* cs, float* sn, float* r );
}

//wrappers for OpenBLAS/LAPACK - can be easily modified to use regular BLAS
//right now the inputs are simplified for the fastBMA use - the full set of input parms can be added later for full BLAS function if needed

//multiply vector by transpose of matrix	wraps dgemv/sgemv
void mtrv(int nRows, int nCols, float *A, int Aldr, float *b, float *ATb);
void mtrv(int nRows, int nCols, double *A, int Aldr, double *b, double *ATb);

//square the matrix AT*A  wraps dgemm/sgemm
void sqmm(int nRows,int nCols,float *A,int Aldr, float *ATA,int ATAldr);
void sqmm(int nRows,int nCols,double *A,int Aldr, double *ATA,int ATAldr);
void sqmm(int nRows,int nCols,float *A,int Aldr, float *ATA,int ATAldr,int nThreads);
void sqmm(int nRows,int nCols,double *A,int Aldr, double *ATA,int ATAldr,int nThreads);
//lartg LAPACK's version of rotg wraps dlartg/slartg
void lartg (double* f, double* g, double* cs, double* sn, double* r);
void lartg (float* f, float* g, float* cs, float* sn, float* r);

//dot product - wraps ddot/sdot
double dot(int n,double *x,double *y);
float dot(int n,float *x,float *y);

//vector addition wraps daxpy/saxpy
double axpy (int n,double a,double *x,double *y);
float axpy (int n,float a,float *x,float *y);

//triangle solver wraps dtrsv/strsv
void trsvutr(int n,double *R, int Rldr, double *v);
void trsvutr(int n,float *R, int Rldr, float *v);

//cholesky wraps dpotrf/spotrf
void potrf(char ul ,int n,float *R,int Rldr);
void potrf(char ul ,int n,double *R,int Rldr);

//functor for optimization - allows for just the parameter to be optimized to be exposed to the optimization library routines
template <class T> class BMAoptimizeFunction{
  public:
	 BMAoptimizeFunction  (T *ATA,int nVars,int nRows,int nCols,int *pord,T *ATb,T sst, T btb, double *postProbs, int *parents, int *npostProbs, double *logpriors,double logOR, BestModelRet *bestModelRet) : _ATA(ATA), _nVars(nVars), _nRows(nRows), _nCols(nCols), _pord(pord), _ATb (ATb), _sst (sst), _btb(btb), _postProbs(postProbs), _parents(parents), _npostProbs (npostProbs), _logpriors(logpriors), _logOR(logOR), _theModelRet(bestModelRet){}
	 double operator () (double g0){
		 //kaiyuan return
		 _theModelRet = chooseBestModels <T> (g0,_ATA,_nVars,_nRows,_nCols,_pord,_ATb, _sst, _btb,_postProbs, _parents, _npostProbs, _logpriors,_logOR,_theModelRet); 
	     /*r2s = _theModelRet->r2s;
		 bics = _theModelRet->bics;
	     nModels = _theModelRet->nModels;
         nmodelschecked = _theModelRet->nmodelschecked;
		 old_postProbs = _theModelRet->old_postProbs;
		 size = _theModelRet->size;
		 whichMatrix = _theModelRet->whichMatrix;*/
		 //cerr << "*********** functor: " << _theModelRet->nModels << endl;
		 //cerr << "optimize return value: " << theModelRet->retvalue << endl;
		 return _theModelRet->retvalue;
	 } 
	/*double *r2s;
	double *bics;
	double *old_postProbs;
	int nModels;
    int	nmodelschecked;
	int *size;
	int **whichMatrix;*/
	BestModelRet *_theModelRet;
	private:
	
	T *_ATA;
	int _nVars;
	int _nRows;
	int _nCols;
	int *_pord;
	T *_ATb;
	T _sst;
	T _btb;
	double *_postProbs;
	int *_parents;
	int *_npostProbs;
	double *_logpriors;
	double _logOR;
	
};



template <class T> FastScanBMAgRet* fastScanBMA_g(T *mATA, T *mATb,T btb,T sst, int ignoreIndex, T *priorProbs,double *postProbs,int *parents, int nRows, int nCols, int nVars, double logOR ,double g, int optimizeBits,int maxOptimizeCycles){

 double *logpriors=new double[nVars]; //always keep this as double as the differences may be very small
 int npostProbs=0; //counter for final number of postProbs; 
 //sort indices decreasing by scores
 int *pord=new int[nCols];
 sort_by_scores(nCols,priorProbs,pord,0);
 if(ignoreIndex >= 0){
		int j=0;
		int i=0;
		while(j <nVars && i <nCols){
			if(pord[i] != ignoreIndex){
				logpriors[j]=log(priorProbs[pord[i]])-log(1-priorProbs[pord[i]]);
		  pord[j++]=pord[i];
			}
		 i++;
		}
		nVars=j;
	}	
 else{ 
  for (int i=0;i<nVars;i++)
   logpriors[i]=log(priorProbs[pord[i]])-log(1-priorProbs[pord[i]]);
	}
 //here we will use the sorted indexing from 1 to nVar - nVars may be smaller than nCols
  T *ATA= new T [(nVars+1)*(nVars+1)];
  T *ATb= new T [nVars+1];

  //reorder mATA and mATb to match sorted ordering
  //could do indirect addressing but copying is probably scales better especially when there are multiple threads  
  {
   //first column/row reserved ones "variable"
   //so if i/j is zero map to zero otherwise map to pord[i]/pord[j]
   //copy 1s column
   
   //first row is ones variable x ones variable
   ATA[0]=mATA[0];
   ATb[0]=mATb[0];
   
   //next rows are from the real variables
   for(int rowATA=1;rowATA<nVars+1;rowATA++){
		  ATA[rowATA]=mATA[pord[rowATA-1]+1];
			}
			
			//copy other columns - careful with row corresonding to ones variable 
   for(int colATA=1;colATA<nVars+1;colATA++){
	  	const int colmATA=pord[colATA-1]+1;
    ATb[colATA]=mATb[colmATA];
    T* const mATAslice=mATA+(colmATA*(nCols+1));
    T* const ATAslice=ATA+(colATA*(nVars+1));
    ATAslice[0]=mATAslice[0];
    for(int rowATA=1;rowATA<nVars+1;rowATA++){
					ATAslice[rowATA]=mATAslice[pord[rowATA-1]+1];
		 	}
			}	
	 }
	
	int nIterations=0;
	bool doneOptimizing=0;
	BestModelRet *bestModelRet = new BestModelRet;
	if(optimizeBits){
		//do a minimization for g
		
		//cerr << "optimize! max number: " << maxOptimizeCycles << endl;
		typedef std::pair<T, T> Result;
		double g0=g;
		boost::uintmax_t max_iter=maxOptimizeCycles;
		BMAoptimizeFunction<T> fuctionParam = BMAoptimizeFunction<T>(ATA,nVars,nRows,nCols,pord,ATb,sst,btb,postProbs,parents,&npostProbs,logpriors,logOR, bestModelRet);
		//cout << "g_op\n";
		Result r2 = boost::math::tools::brent_find_minima(fuctionParam, (T) 1, (T)nVars, optimizeBits, max_iter);
		//cerr << "model return: " << fuctionParam._theModelRet << endl;
		//kaiyuan return
		bestModelRet->r2s = fuctionParam._theModelRet->r2s;
		bestModelRet->bics = fuctionParam._theModelRet->bics;
		bestModelRet->nModels = fuctionParam._theModelRet->nModels;
		//cerr << "*********** g call: " << bestModelRet->nModels << endl;
		bestModelRet->nmodelschecked = fuctionParam._theModelRet->nmodelschecked;
		bestModelRet->old_postProbs = fuctionParam._theModelRet->old_postProbs;
		bestModelRet->size = fuctionParam._theModelRet->size;
		bestModelRet->whichMatrix = fuctionParam._theModelRet->whichMatrix;
		//cerr << "g_op_finish2" << endl;
		
  //std::cout << "g=" << r2.first << " f=" << r2.second << std::endl;
	}
	else{
		//cerr << "not optimize!" << endl;
		//just use the current g
			//cout << "g_nonop\n";
		bestModelRet = chooseBestModels(g,ATA,nVars,nRows,nCols,pord,ATb,sst,btb,postProbs,parents,&npostProbs,logpriors,logOR, NULL);
		//cout << "g_nonop_finish\n";
	}	
	delete [] ATA;
	delete [] ATb;
	delete [] logpriors;
	delete [] pord;
	 
	//kaiyuan return
	FastScanBMAgRet *fastScanBMAgRet = new FastScanBMAgRet;
	fastScanBMAgRet->r2s = bestModelRet->r2s;
	fastScanBMAgRet->bics = bestModelRet->bics;
	fastScanBMAgRet->nModels = bestModelRet->nModels;
	//cerr << "*********** g return: " << fastScanBMAgRet->nModels << endl;
	fastScanBMAgRet->nmodelschecked = bestModelRet->nmodelschecked;
	fastScanBMAgRet->old_postProbs = bestModelRet->old_postProbs;
	fastScanBMAgRet->size = bestModelRet->size;
	fastScanBMAgRet->whichMatrix = bestModelRet->whichMatrix;
    fastScanBMAgRet->npostProbs = npostProbs;
    return fastScanBMAgRet;
}




//template <class T> T chooseBestModels(double g,T *ATA,int nVars,int nRows,int nCols,int *pord,T *ATb,T sst, T btb, double *postProbs, int *parents, int *npostProbs, double *logpriors,double logOR){
template <class T> BestModelRet* chooseBestModels(double g,T *ATA,int nVars,int nRows,int nCols,int *pord,T *ATb,T sst, T btb, double *postProbs, int *parents, int *npostProbs, double *logpriors,double logOR, BestModelRet* theModelRet){
  //start loop here when optimizing g0
  std::set<ModelSet <T>> keepModels;
  std::set<ModelSet <T>> activeModels;
  std::set<ModelSet <T>> nextModels;
  ModelIndices modelIndices(nVars);
  activeModels.insert(ModelSet<T>(modelIndices, 0, 0, 0));
   //cout << "start choose model\n";
  T minBIC = 0;
  T candidateR2 = 0;
  T candidateBIC = 0;
  T cutoffBIC = logOR;
 
  typename std::set<ModelSet <T> >::iterator it,it1;
  std::unordered_set<CompactModelIndices> checkedModels;
	
 // Loop through while we have active models
 // to search around
  int curpass=0;
  while ( ((int)activeModels.size()) > 0 ) {
	  //cerr << "choose model while: " << curpass << "\n";
   curpass++;
   for ( it = activeModels.begin(); it != activeModels.end(); it++ ){
 			copy_indices(modelIndices,it->modelIndices);
 			ModelIndices tempmodelIndices=modelIndices;
 			
 		 //Do a first pass to see which inserts/deletes are needed
 		 //This saves overhead of creating and copying data to large arrays
 		 
 			const double current_logprior=it->logprior;
 			int inserts[nVars];
 			int deletes[nVars];
 			int ndeleted=0;
 			int ninserted=0;
 			//see which changes need to be made
 		 for (int i = 0; i < nVars; i++ ) {
 			//go through active models and add or remove model i
     if (modelIndices.nModels && modelIndices.index[i]){
 				 if (modelIndices.nModels >1){
 						tempmodelIndices.deleteElement_unordered(i);
       CompactModelIndices mString = CompactModelIndices(tempmodelIndices);
       if((int)checkedModels.count(mString) < 1){
 						 deletes[ndeleted++]=i;
 						 checkedModels.insert(mString);
 						}
 						tempmodelIndices=modelIndices;
 					}	
 				}
     else{
 					tempmodelIndices.insertElement(i);
      CompactModelIndices mString = CompactModelIndices(tempmodelIndices);
      if((int)checkedModels.count(mString) < 1){
 						inserts[ninserted++]=i;
 						checkedModels.insert(mString);
 					}
 					tempmodelIndices=modelIndices;	
 				}
 			}
 			//now pass all the non-duplicated sets and determine the rsquared coefficients 
 			//do inserts/denovo
 			const int nModels=modelIndices.nModels;
 			if(ninserted){
 				const int p=nModels+2;
 				//de novo
 				if(nModels <1){
 					T *Rarray=new T[(p+1)*(p+1)];
 					for(int k=0;k<ninserted;k++){
 						//add model i
 						const int i=inserts[k];
 						const double logprior=current_logprior+logpriors[i];
 						tempmodelIndices=modelIndices;	
 						tempmodelIndices.insertElement(i);
 					 T rv=getR2_full(tempmodelIndices,ATA,nVars+1,ATb,btb,Rarray,p+1);
 						candidateR2 = 1.0-(rv/sst);
 						candidateBIC = (nRows-1) * log(1 + g*(1-candidateR2)) + (1 + (int)tempmodelIndices.nModels- nRows) * log(1 + g)-2.0*logprior;
						 if ( candidateBIC - minBIC < logOR ) {
							 nextModels.insert(ModelSet<T>(tempmodelIndices, candidateR2, candidateBIC,logprior,Rarray,p,p+1));
						 	minBIC = ((minBIC < candidateBIC) ? minBIC : candidateBIC);		      
						 }
					 } 
					 delete [] Rarray;
				 }
				 //insert	
				 else{
				  T *Rplus=new T [p*p];
				  it->R.tr_to_sq(Rplus,p);
			 	 for(int k=0;k<ninserted;k++){
						 const int i=inserts[k];
						 const double logprior=current_logprior+logpriors[i];
						 tempmodelIndices=modelIndices;
			 	  tempmodelIndices.insertElement(i);
						 T rv=getR2_up(tempmodelIndices,ATA,nVars+1,ATb,btb,Rplus,p);
						 candidateR2 = 1.0-(rv/sst);
						 candidateBIC = (nRows-1) * log(1 + g*(1-candidateR2)) + (1 + (int)tempmodelIndices.nModels- nRows) * log(1 + g)-2.0*logprior;
						 if ( candidateBIC - minBIC < logOR ) {	      
							 nextModels.insert(ModelSet<T>(tempmodelIndices, candidateR2, candidateBIC,logprior,Rplus,p,p));
						 	minBIC = ((minBIC < candidateBIC) ? minBIC : candidateBIC);
					 	}
				 	}
			 		delete[] Rplus;
			 	}	
			 }	
			 //check deletes
			 if(ndeleted){
				 const int p=nModels;
				 //de novo
			  if(p <=2){
					 T *Rarray=new T[(p+1)*(p+1)];
      for(int k=0;k<ndeleted;k++){
						 const int i=deletes[k];
						 const double logprior=current_logprior-logpriors[i];
					  tempmodelIndices=modelIndices;	
						 int delete_index=tempmodelIndices.deleteElement_unordered(i);
					  T rv=getR2_full(tempmodelIndices,ATA,nVars+1,ATb,btb,Rarray,p+1);
       candidateR2 = 1.0-(rv/sst);
       candidateBIC = (nRows-1) * log(1 + g*(1-candidateR2)) + (1 + (int)tempmodelIndices.nModels- nRows) * log(1 + g)-2.0*logprior;
       if ( candidateBIC - minBIC < logOR ) {
        nextModels.insert(ModelSet<T>(tempmodelIndices, candidateR2, candidateBIC,logprior,Rarray,p,p+1));
        minBIC = ((minBIC < candidateBIC) ? minBIC : candidateBIC);		      
       }
				 	} 
				 	delete [] Rarray;
				 }
				 //delete	
				 else{
					 T *Rminus=new T[(p+1)*(p+1)];
	     for(int k=0;k<ndeleted;k++){
						 const int i=deletes[k];
						 const double logprior=current_logprior-logpriors[i];
						 tempmodelIndices=modelIndices;
				 	 int delete_index=tempmodelIndices.deleteElement_unordered(i);
				 	 //the first column (0) is the column of ones but the index stored is 1 greater than the modelIndex 
				 	 //so j=modelIndices+1-1;
				 	 int j=modelIndices.index[i]; 
       //copy matrix and delete jth colum
       //memset(Rminus,0,(p+1)*(p+1)*sizeof(T));
       it->R.tr_to_sq_delj(Rminus,p+1,j);
						 T rv=getR2_down(p+1,modelIndices,ATb,btb,Rminus,p+1,j);
       candidateR2 = 1.0-(rv/sst);
       candidateBIC = (nRows-1) * log(1 + g*(1-candidateR2)) + (1 + (int)tempmodelIndices.nModels- nRows) * log(1 + g)-2.0*logprior;
       if ( candidateBIC - minBIC < logOR ) {;
					 		tempmodelIndices.order_deletion(delete_index);
        nextModels.insert(ModelSet<T>(tempmodelIndices, candidateR2, candidateBIC,logprior,Rminus,p,p+1));
        minBIC = ((minBIC < candidateBIC) ? minBIC : candidateBIC);
       }
				 	}
				 	delete[] Rminus;
			 	}
    }	
		 }
   cutoffBIC = minBIC + logOR;

   // Remove models with bic greater than the cutoff
   it = keepModels.begin();
   while( it != keepModels.end() && (*it).bic <= cutoffBIC ) {
    it++;
   }
   keepModels.erase(it, keepModels.end());
   // Add good models from the active models to keep
   // and clear the active models
   it = activeModels.begin();
   while( it != activeModels.end() && (*it).bic <= cutoffBIC ) {
    it++;
   }
   keepModels.insert(activeModels.begin(), it);
   activeModels.clear();
   // Add good models from the next models to the active models
   // and clear the next models
   it = nextModels.begin();				
   while( it != nextModels.end() && (*it).bic <= cutoffBIC ) {
    it++;
   }
   activeModels.insert(nextModels.begin(), it);
   nextModels.clear();
   //cerr << "model size: " << (int)activeModels.size() << "\n";
  }
  //cerr << "finish while\n";
  const double maxBIC = (double) keepModels.rbegin()->bic;
  //cerr << "before memset\n";
  memset(postProbs,0,nCols*sizeof(double));
  //cerr << "after memset\n";
  double postProbnorm=0;
  T retvalue=0;

  
  //Kaiyuan return
  int nModelsRet = (int)keepModels.size();
  //cerr << "init nModel" << nModelsRet << endl;
	//cerr << ", test 1\n";
  double *r2sRet = new double[nModelsRet];
  //cerr << "test 1.1\n";
  double *bicsRet = new double[nModelsRet];
  //cerr << "test 1.2\n";
  double *old_postProbs = new double[nModelsRet];
 // cerr << "test 1.3\n";
  int *size = new int[nModelsRet];
  //cerr << "test 2\n";
  int **whichMatrix = new int*[nModelsRet];
  for (int i = 0; i < nModelsRet; i++) {
	  whichMatrix[i] = new int[nCols];
	  for (int j = 0; j < nCols; j++)
		  whichMatrix[i][j] = 0;
  }
  //cerr << "test 3\n";
	  
  //cerr << "start return model\n";
  int retCounter = 0;
  for ( it = keepModels.begin(); it != keepModels.end(); it++ ){
			const double postProb=exp((-0.5)*((double) it->bic-maxBIC));
			postProbnorm+=postProb;
			const int *list=it->modelIndices.list;
			const int nModels=it->modelIndices.nModels;
			old_postProbs[retCounter] = postProb;
			for(int i=0;i<nModels;i++){
				whichMatrix[retCounter][pord[list[i]]] = 1;
				postProbs[pord[list[i]]]+=postProb;
			}
			T r2= it->r2;
			r2sRet[retCounter] = r2;
			bicsRet[retCounter] = it->bic;
			size[retCounter] = nModels;
			retvalue += (T) (nVars - nModels - 1.0) *log(1.0+g) - (T)(nVars-1.0)*log(1.0+g*(1.0-r2));
			retCounter++;
		}
		
		
		postProbnorm=(double)1/postProbnorm;
		for (int i = 0; i < nModelsRet; i++) {
			old_postProbs[i] = old_postProbs[i] * postProbnorm;
		}
		int my_npostProbs=0;	
		T rvalue=0;
		//cout << "finish keep model\n";
  for (int i=0;i<nCols;i++){
			if(postProbs[i]){
			 postProbs[my_npostProbs]=postProbs[i]*postProbnorm;
			 parents[my_npostProbs++]=i;
			}
		}
		*npostProbs=my_npostProbs;
		//cout << "g= " << g <<'\t' << -retvalue <<endl;
		//return(-retvalue);
		BestModelRet *bestModelRet;
		if (theModelRet == NULL)
			bestModelRet= new BestModelRet;
		else
			bestModelRet = theModelRet;
		
		bestModelRet->r2s = r2sRet;
		bestModelRet->bics = bicsRet;
		bestModelRet->nModels = nModelsRet;
		//cerr << "*********** model function: " << nModelsRet << endl;
		bestModelRet->nmodelschecked = (int)checkedModels.size();
		bestModelRet->old_postProbs=old_postProbs;
		bestModelRet->size=size;
		bestModelRet->whichMatrix=whichMatrix;
		bestModelRet->retvalue = -retvalue;
		return bestModelRet;
	}

/*** kaiyuan ***/
/*void myEdge(EdgeList* edges) {
	cerr << "initial edges:" << endl;
	for (int i = 0; i < edges->nNodes; i++) {
		for (int j = 0; j < edges->nParents[i]; j++) {
			cerr << edges->parents[i][j] + 1 << " -- " << i + 1 << ": " << edges->edgeWeights[i][j] << endl;
		}
	}
	
	
}*/


//template <class T> EdgeList* nonSelfBMA(float gPrior,int optimizeBits,int maxOptimizeCycles,float uPrior,float oddsRatio,int nVars,string matrixFile,T ***rProbs,string priorsListFile,int nThreads, bool noHeader,vector <string> &headers){
template <class T> BMARetStruct* nonSelfBMA(float gPrior,int optimizeBits,int maxOptimizeCycles,float uPrior,float oddsRatio,T **data,int nGenes,int nSamples,T ***rProbs,int nThreads,vector <string> &headers, int geneIndex, bool noPrune, float edgeMin, float edgeTol){
/*	ifstream inFile(matrixFile,ios::in);
	int nLines=std::count(std::istreambuf_iterator<char>(inFile),  std::istreambuf_iterator<char>(), '\n'); 
	inFile.clear(); inFile.seekg(0, std::ios::beg); //rewind file

 if (!inFile.is_open())return(0);
	string token,line,*headings=0;
	int nGenes=0;
	T **data=0;
	const T uniform_prob=(T) uPrior;
	const int nRows=(noHeader)? nLines:nLines-1;


	//first line is headings line - with fields 'Sample id GeneNames"
	if ( getline (inFile,line,'\n') ){
		std::istringstream iss(line);
		int nFields=std::count(std::istreambuf_iterator<char>(iss),  std::istreambuf_iterator<char>(), '\t')+1;
		iss.clear(); iss.seekg(0, std::ios::beg);
		nGenes=nFields-1;
		
		data=new T*[nGenes];
		if(noHeader){
			inFile.seekg(0);
		}	
		else{
   headers.resize(0);
   headers.reserve(nGenes);
   getline(iss, token, '\t');
   while(getline(iss, token, '\t')){
		 	if(token[0] == '"'){
     headers.push_back(token.substr(1,token.size()-2));
		  }
		  else headers.push_back(token);		
		 }
		}
		for(int i=0;i<nGenes;i++) data[i]=new T[nRows];
	}
	int nSamples=0;
		//read the data
 while ( getline (inFile,line,'\n') ){
		std::istringstream iss(line);
		getline(iss, token, '\t');//sample name		
		//split each element into tokens
		int j=0;
		while(getline(iss, token, '\t')){
			data[j++][nSamples]=(T) atof(token.c_str());
  }
  nSamples++;
	}
 inFile.close();*/
 //inFile close *************************
 FastScanBMAgRet *fastScanBMAgRet = new FastScanBMAgRet;
 int nRows = nSamples;
 const T uniform_prob=(T) uPrior;


	EdgeList *edgeList= new EdgeList(nGenes); 
	T *A=new T [(nGenes+1)*nRows];
	T *ATA=new T[(nGenes+1)*(nGenes+1)];
 const int ATAldr=nGenes+1;
 const int Aldr=nRows;
  

  //all the information is stored in the data array - data[gene_index][sample_index];
  //this order allows the column (gene) slices to be easil used
  //there are 100 genes and  582 rows - 6 time points per row
  // y vector t1-t5 xmatrix will be rowx t0-t4

  //column of ones to force calculation of intercepts
  for (int i=0;i<nRows;i++) A[i]=1;

		//copy variable columns
		{
   T *dest=A+Aldr;
   for (int j=0;j<nGenes;j++){
				for (int n=0;n<nRows;n++){
					*dest=data[j][n];
					dest++;
		  }
   }
		}
			//square the matrix;
		sqmm(nRows,nGenes+1,A,Aldr,ATA,ATAldr,nThreads);
  const T logOR=log((T) oddsRatio);
		//const int my_nVars=(nVars) ? nVars:nGenes;
  	  	  const int my_nVars= nGenes; // Kai **********************************************
		const T g= (gPrior)? (T)gPrior : (T) my_nVars;
		/*if(!*rProbs && priorsListFile != ""){
			//if no priors provided - read them in and store them in rProbs
			*rProbs=new T*[nGenes];
			for (int i=0;i<nGenes;i++){
				(*rProbs)[i]=new T[nGenes];
			}	
			readPriorsList(priorsListFile,headers,*rProbs,uniform_prob);
		}	*/ //no need to read rProbs file
  //now prepare each y vector 
  #pragma omp parallel for num_threads(nThreads)
		for (int i=0;i<nGenes;i++){
			//cout << "loop: " << i << "\n";
			int *tparents=new int[nGenes];
			T *b=new T[nRows];
			T *ATb=new T[nGenes+1];
			T btb,sst;
			double *postProbs=new double[nGenes];
			T *priors=new T[nGenes];
			if(*rProbs && (*rProbs)[i]){
				T* const slice = (*rProbs)[i];
				for (int k=0;k<nGenes;k++)
				 priors[k]=(T) slice[k];
			}
			else{
				for (int k=0;k<nGenes;k++)
				 priors[k]=uniform_prob;
			}		
			//set up y vector
			for (int n=0;n<nRows;n++){
				b[n]=data[i][n];
			}			 
			

			//multiply AT b to get ATb
		 mtrv(nRows,nGenes+1,A,Aldr,b,ATb);
   btb=dot(nRows,b,b);
   sst=calculate_sst(nRows,b,A); //A is passed because the first column is a column of 1s which is useful to find sum of y components using the dot product 
			//what to set logOR and g to
			//kaiyuan return
			FastScanBMAgRet *tempRet;
			
			/*cerr << "call _g: " << i <<"\n";
			
			cerr << "ATA: " << (nGenes+1) << ", " << (nGenes+1) << endl;
			for (int k = 0; k < (nGenes+1)*(nGenes+1); k++)
				cerr << ATA[k] << ", ";
			cerr << endl;
			
			cerr << "ATb: " << nGenes+1 << endl;
			for (int k = 0; k < nGenes+1; k++)
				cerr << ATb[k] << ", ";
			cerr << endl;
			
			cerr << "btb: " << btb << endl;
			
			cerr << "sst: " << sst << endl;
			
			cerr << "i: " << i << endl;
			
			cerr << "priors: " << nGenes << endl;
			for (int k = 0; k < nGenes; k++)
				cerr << priors[k] << ", ";
			cerr << endl;
			
			cerr << "postProbs: " << nGenes << endl;
			for (int k = 0; k < nGenes; k++)
				cerr << postProbs[k] << ", ";
			cerr << endl;
			
			//tparents
			
			cerr << "nRows: " << nRows << endl;
			cerr << "nGenes: " << nGenes << endl;
			cerr << "my_nVars: " << my_nVars << endl;
			cerr << "logOR: " << logOR << endl;
			cerr << "g: " << g << endl;
			cerr << "optimizeBits: " << optimizeBits << endl;
			cerr << "maxOptimizeCycles: " << maxOptimizeCycles << endl;*/
			
			tempRet = fastScanBMA_g(ATA,ATb,btb,sst,i,priors,postProbs,tparents,nRows, nGenes,my_nVars, logOR,g,optimizeBits,maxOptimizeCycles);
			int nEdges=tempRet->npostProbs;
			//cerr << nEdges << ", finish _g: " << i <<"\n"; 
			if (i == geneIndex || i == 0) {
				fastScanBMAgRet = tempRet;
			}	
			
   if(nEdges){
				edgeList->nParents[i]=nEdges;
			 edgeList->parents[i]=new	int[nEdges];
			 memmove(edgeList->parents[i],tparents,nEdges*sizeof(int));
			 edgeList->edgeWeights[i]=new	float[nEdges];
			 for(int k=0;k<nEdges;k++)
			  edgeList->edgeWeights[i][k]=postProbs[k];
			}
   //read return and delete each of the arrays as necessary
			//cout << "finish loop: " << i <<"\n"; 
			delete[] priors;
			delete[] postProbs;
			delete[] tparents;
			delete[] b;
			delete[] ATb;
			
			//cout << "finish delete: " << i <<"\n"; 
		}
	
  delete[] A;
	 delete[] ATA;
	 
	 //cerr << "before prune\n";
	 if(!noPrune){
		 //cerr << "do prune";
		edgeList->prune_edges(edgeMin/4.0f,edgeTol);
	 }
	 //myEdge(edgeList);
	 //cerr << "after prune\n";
	 //kaiyuan return
	 BMARetStruct *theBMARetStruct = new BMARetStruct;
	 
	 //cerr << "return edgeList\n";
	 theBMARetStruct->edgeWeights = edgeList->edgeWeights;
	 theBMARetStruct->parents = edgeList->parents;
	 theBMARetStruct->nParents = edgeList->nParents;
	 theBMARetStruct->nNodes = edgeList->nNodes;
	 
	 //cerr << "return all other\n";
	 theBMARetStruct->postProbs = fastScanBMAgRet->old_postProbs;
	 theBMARetStruct->r2s = fastScanBMAgRet->r2s;
	 theBMARetStruct->bics = fastScanBMAgRet->bics;
	 theBMARetStruct->size = fastScanBMAgRet->size;
	 theBMARetStruct->whichMatrix = fastScanBMAgRet->whichMatrix;
	 theBMARetStruct->nModels = fastScanBMAgRet->nModels;
	 
	 theBMARetStruct->checkedModels = fastScanBMAgRet->nmodelschecked;
	 
	 //cerr << "return finish\n";
	return theBMARetStruct;
}   

//template <class T> BMARetStruct* timeSeriesBMA(float gPrior,int optimizeBits,int maxOptimizeCycles,float uPrior,float oddsRatio,int nVars,string matrixFile,T ***rProbs,string priorsListFile, int nThreads, bool noHeader,bool useResiduals,vector<string> &headers){
template <class T> BMARetStruct* timeSeriesBMA(int nTimePoints, float gPrior,int optimizeBits,int maxOptimizeCycles,float uPrior,float oddsRatio,T **data,int nGenes,int nSamples,T ***rProbs,int nThreads, vector <string> &headers, int geneIndex, bool noPrune, float edgeMin, float edgeTol){

	/*ifstream inFile(matrixFile,ios::in);
	int nLines=std::count(std::istreambuf_iterator<char>(inFile),  std::istreambuf_iterator<char>(), '\n'); 
	inFile.clear(); inFile.seekg(0, std::ios::beg); //rewind file

 if (!inFile.is_open())return(0);
	string token,line;
	int nGenes=0;
	T **data=0;
	const T uniform_prob=(T) uPrior;
	const int nReplicates=(noHeader)? nLines:nLines-1;

	int *replicates=new int[nReplicates];
	//first line is headings line - with fields 'Identifier Replicate/Group Genes"
	if ( getline (inFile,line,'\n') ){
		std::istringstream iss(line);
		int nFields=std::count(std::istreambuf_iterator<char>(iss),  std::istreambuf_iterator<char>(), '\t')+1;
		iss.clear(); iss.seekg(0, std::ios::beg);
		nGenes=nFields-3;
	 data=new T*[nGenes];
		if(noHeader){
			inFile.seekg(0);
		}	
		else{
   headers.resize(0);
   headers.reserve(nGenes);
   getline(iss, token, '\t');getline(iss, token, '\t');getline(iss, token, '\t'); //skip 3 fields for headers
   while(getline(iss, token, '\t')){
		 	if(token[0] == '"'){
     headers.push_back(token.substr(1,token.size()-2));
		  }
		  else headers.push_back(token);		
		 }
		}
	 for(int i=0;i<nGenes;i++) data[i]=new T[nReplicates];
	}
	int nSamples=0;				
		//read the data
  while ( getline (inFile,line,'\n') ){
			std::istringstream iss(line);
			getline(iss, token, '\t');//sample name		
			if (getline(iss, token, '\t')){//replicate name
			 if(token[0] == '"'){
			 	replicates[nSamples]=atoi((token.substr(1,token.size()-2)).c_str());
		  }
		  else
				 replicates[nSamples]=atoi(token.c_str());
			}
			getline(iss, token, '\t');//sample time
			//split each element into tokens
			int j=0;
			while(getline(iss, token, '\t')){
				data[j++][nSamples]=(T) atof(token.c_str());
   }
   nSamples++;
		}
  inFile.close();*/
  //infile closed******************
  FastScanBMAgRet *fastScanBMAgRet = new FastScanBMAgRet;
	const T uniform_prob=(T) uPrior;
	//const int nReplicates=nSamples;
	//int *replicates=new int[nReplicates];
	
  //count times and groups
  
        
		int nTimes=nTimePoints;
		int nGroups=nSamples / nTimePoints;
		//cerr << "nTimes:" << nTimes << ", nGrops: " << nGroups << "\n";
		/*for (int i=0;i<nSamples;i++){
			if(i==0 || replicates[i] != replicates[i-1]){
				nGroups++;
			}	
		 if(replicates[i]==1){
				nTimes++;
			}
		}
		(useResiduals){
			T *residuals=new T[(nTimes-1)*nGroups];
			for (int g=0;g<nGenes;g++){
				T* const values=data[g];
				TimeSeriesValuesToResiduals(values,residuals,nTimes,nGroups);
				memmove(data[g],residuals,(nTimes-1)*nGroups*sizeof(T));
			}
			delete[] residuals;
  //we throw away the zero time point and need to adjust the number of samples
			nSamples=	nGroups*(nTimes-1);
			nTimes--; 
		}
		delete[] replicates;*/
		
		
		//const int nRows=(useResiduals)?(nTimes-2)*nGroups:(nTimes-1)*nGroups;
	const int nRows=(nTimes-1)*nGroups;
	//const int nRows=nTimes*nGroups;//kaiyuan change***************
		EdgeList *edgeList= new EdgeList(nGenes); 
		T *A=new T [(nGenes+1)*nRows];
		T *ATA=new T[(nGenes+1)*(nGenes+1)];
  const int ATAldr=nGenes+1;
  const int Aldr=nRows;
  

  //all the information is stored in the data array - data[gene_index][sample_index];
  //this order allows the column (gene) slices to be easil used
  //there are 100 genes and  582 rows - 6 time points per row
  // y vector t1-t5 xmatrix will be rowx t0-t4

  //column of ones to force calculation of intercepts
  for (int i=0;i<nRows;i++) A[i]=1;

		//copy variable columns
		{
   T *dest=A+Aldr;
   for (int j=0;j<nGenes;j++){
		for (int n=0;n<nSamples;n++){
			  if(n%nTimes != nTimes-1){
						*dest=data[j][n];
						*dest++;
					}
		  }
   }
		}

			//square the matrix;
		sqmm(nRows,nGenes+1,A,Aldr,ATA,ATAldr,nThreads);
  const T logOR=log((T) oddsRatio);
		//const int my_nVars=(nVars) ? nVars:nGenes;
  	  const int my_nVars=nGenes;//kai ******************************
		const T g= (gPrior)? (T)gPrior : (T) my_nVars;
		/*if(!*rProbs && priorsListFile != ""){
			//if no priors provided - read them in and store them in rProbs
			*rProbs=new T*[nGenes];
			for (int i=0;i<nGenes;i++){
				(*rProbs)[i]=new T[nGenes];
			}	
			readPriorsList(priorsListFile,headers,*rProbs,uniform_prob);
		}	*/ // no need to read rprob file
  //now prepare each y vector 
  /*** kaiyuan ***/
	/*cerr << "nTimes: " << nTimes << endl;
	cerr << "g: " << g << endl;
	cerr << "optimizeBits: " << optimizeBits << endl;
	cerr << "maxOptimizeCycles: " << maxOptimizeCycles << endl;
	cerr << "uniform_prob: " << uniform_prob << endl;
	cerr << "oddsRatio: " << oddsRatio << endl;
	cerr << "nGenes: " << nGenes << endl;
	cerr << "nSamples: " << nSamples << endl;
	cerr << "nGroups: " << nGroups << endl;
	cerr << "nRows: " << nRows << endl;*/
  #pragma omp parallel for num_threads(nThreads)
		for (int i=0;i<nGenes;i++){
			//cerr << "loop: " << i << endl;
			int *tparents=new int[nGenes];
			T *b=new T[nRows];
			T *ATb=new T[nGenes+1];
			T btb,sst;
			double *postProbs=new double[nGenes];
			T *priors=new T[nGenes];
			if(*rProbs && (*rProbs)[i]){
				T* const slice = (*rProbs)[i];
				for (int k=0;k<nGenes;k++)
				 priors[k]=(T) slice[k];
			}
			else{
				for (int k=0;k<nGenes;k++)
				 priors[k]=uniform_prob;
			}		
			//set up y vector
			{
				int j=0;
				for (int n=0;n<nSamples;n++){
					if(n%nTimes) b[j++]=data[i][n];
				}			 
			}
   
			//multiply AT b to get ATb
		 mtrv(nRows,nGenes+1,A,Aldr,b,ATb);
   btb=dot(nRows,b,b);
   sst=calculate_sst(nRows,b,A); //A is passed because the first column is a column of 1s which is useful to find sum of y components using the dot product 
			//what to set logOR and g to
			FastScanBMAgRet *tempRet;
			
			/*cerr << "call _g: " << i <<"\n";
			
			cerr << "ATA: " << (nGenes+1) << ", " << (nGenes+1) << endl;
			for (int k = 0; k < (nGenes+1)*(nGenes+1); k++)
				cerr << ATA[k] << ", ";
			cerr << endl;
			
			cerr << "ATb: " << nGenes+1 << endl;
			for (int k = 0; k < nGenes+1; k++)
				cerr << ATb[k] << ", ";
			cerr << endl;
			
			cerr << "btb: " << btb << endl;
			
			cerr << "sst: " << sst << endl;
			
			cerr << "i: " << i << endl;
			
			cerr << "priors: " << nGenes << endl;
			for (int k = 0; k < nGenes; k++)
				cerr << priors[k] << ", ";
			cerr << endl;
			
			cerr << "postProbs: " << nGenes << endl;
			for (int k = 0; k < nGenes; k++)
				cerr << postProbs[k] << ", ";
			cerr << endl;
			
			//tparents
			
			cerr << "nRows: " << nRows << endl;
			cerr << "nGenes: " << nGenes << endl;
			cerr << "my_nVars: " << my_nVars << endl;
			cerr << "logOR: " << logOR << endl;
			cerr << "g: " << g << endl;
			cerr << "optimizeBits: " << optimizeBits << endl;
			cerr << "maxOptimizeCycles: " << maxOptimizeCycles << endl;*/
			
			tempRet = fastScanBMA_g(ATA,ATb,btb,sst,-1,priors,postProbs,tparents,nRows, nGenes,my_nVars, logOR,g,optimizeBits,maxOptimizeCycles);
			int nEdges=tempRet->npostProbs;
			
			if (i == geneIndex || i == 0) {
				//cerr << "must show i == 0: " << i << endl; 
				fastScanBMAgRet = tempRet;
			}
			
   if(nEdges){
				edgeList->nParents[i]=nEdges;
			 edgeList->parents[i]=new	int[nEdges];
			 memmove(edgeList->parents[i],tparents,nEdges*sizeof(int));
			 edgeList->edgeWeights[i]=new	float[nEdges];
			 for(int k=0;k<nEdges;k++)
			  edgeList->edgeWeights[i][k]=postProbs[k];
			}
   //read return and delete each of the arrays as necessary			
			delete[] priors;
			delete[] postProbs;
			delete[] tparents;
			delete[] b;
			delete[] ATb;
		}
		
		
		
  delete[] A;
	 delete[] ATA;
		//return(edgeList);
	if(!noPrune){
		edgeList->prune_edges(edgeMin/4.0f,edgeTol);
	 }
	
	//kaiyuan return
	//myEdge(edgeList);
	 BMARetStruct *theBMARetStruct = new BMARetStruct;
	 
	 theBMARetStruct->edgeWeights = edgeList->edgeWeights;
	 theBMARetStruct->parents = edgeList->parents;
	 theBMARetStruct->nParents = edgeList->nParents;
	 theBMARetStruct->nNodes = edgeList->nNodes;
	 
	 
	 theBMARetStruct->postProbs = fastScanBMAgRet->old_postProbs;
	 theBMARetStruct->r2s = fastScanBMAgRet->r2s;
	 theBMARetStruct->bics = fastScanBMAgRet->bics;
	 theBMARetStruct->size = fastScanBMAgRet->size;
	 theBMARetStruct->whichMatrix = fastScanBMAgRet->whichMatrix;
	 theBMARetStruct->nModels = fastScanBMAgRet->nModels;
	 theBMARetStruct->checkedModels = fastScanBMAgRet->nmodelschecked;
	 //cerr << "*********** g time series: " << fastScanBMAgRet->nModels << endl;
	return theBMARetStruct;
}   
EdgeList* readEdgeListFile(string edgeListFile, vector<string> &headers){
 //returns priors
		ifstream inFile(edgeListFile,ios::in);	
		vector <string> node1;
		vector <string> node2;
		vector <float> weights;
		int j=0;
		if (inFile.is_open()){
		 string token,line;
   while ( getline (inFile,line,'\n')){
			 std::istringstream iss(line);
			 if (getline(iss, token, '\t')){
			 	node1.push_back(token);
    }
 			if (getline(iss, token, '\t')){
			 	node2.push_back(token);
    }
    if (getline(iss, token, '\t')){
			 	weights.push_back(atof(token.c_str()));
    }
		 }		 
		 inFile.close();				
	 }
	 //set up index for nodes
	 unordered_map <string,int> nameIndex;
	 headers.resize(0);
	 int nEdges=node1.size();
  int nNodes=0;
  vector<int> nParents(2*node1.size());
  fill (nParents.begin(),nParents.begin()+nParents.size(),0);  
  {
   unordered_set <string> nameSeen;
	  //create mapping to names
	  for (int i=0;i<nEdges;i++){
		 	if(!nameSeen.count(node1[i])){
		  	nameSeen.insert(node1[i]);
		   headers.push_back(node1[i]);
		   nameIndex[node1[i]]=nNodes++; 
		  }
		  if(!nameSeen.count(node2[i])){
		  	nameSeen.insert(node2[i]);
		   headers.push_back(node2[i]);
		   nameIndex[node2[i]]=nNodes++; 
		  }
		  nParents[nameIndex[node2[i]]]++;
			}
		}
	 //set up edgeList
	 EdgeList *edgeList= new EdgeList(nNodes);
	 for (int i=0;i<nNodes;i++){
   edgeList->parents[i]=new	int[nParents[i]];
   edgeList->edgeWeights[i]=new	float[nParents[i]];
   edgeList->nParents[i]=0;
		} 
		for (int i=0;i<nEdges;i++){
			const int n=nameIndex[node2[i]];
			const int p=edgeList->nParents[n];
			
   edgeList->parents[n][p]=nameIndex[node1[i]];
   edgeList->edgeWeights[n][p]=weights[i];
   edgeList->nParents[n]++;
		}
		return(edgeList);	
	}
template <class T> void readPriorsList(string priorsListFile,vector <string> names, T **priors, T uniform_prob){
 //returns priors
 //format is each gene is in the same order as the gene order of the matrix
 //all genes must be present - no empty fields
  using namespace std; 
  std::unordered_map<string,int> namesMap;
  for(int i=0;i<names.size();i++){
			namesMap[names[i]]=i;
		}
  for (int i=0;i<names.size();i++)
   priors[0][i]=uniform_prob;
  for (int i=1;i<names.size();i++)
   memmove(priors[i],priors[0],sizeof(T)*names.size());  
		ifstream inFile(priorsListFile,ios::in);	;
		if (inFile.is_open()){
   string line;    
		 float value;
		 char parent[1024],child[1024];		 
   while ( getline (inFile,line,'\n')){
			 sscanf(line.c_str(),"%s\t%s\t%f",&parent, &child, &value);    
			 //expects first name to regulate second name
			 string parentStr(parent); 
			 auto parentit = namesMap.find(parentStr);
			 if(parentit != namesMap.end()){
				 string childStr(child);
					auto childit=namesMap.find(childStr);
			  if(childit != namesMap.end()){
						priors[childit->second][parentit->second]=value;
				 }
				}
			}		 
		 inFile.close();				
	 }
	}	
		
template <class T> T** readPriorsMatrix(string priorsFile){
 //returns priors
 //format is each gene is in the same order as the gene order of the matrix
 //all genes must be present - no empty fields 
		ifstream inFile(priorsFile,ios::in);	
		int nlines=std::count(std::istreambuf_iterator<char>(inFile),  std::istreambuf_iterator<char>(), '\n'); 
		inFile.clear(); inFile.seekg(0, std::ios::beg); //rewind file
		int nProbs=nlines-1;
		T **rProbs=new T*[nProbs];
		if (inFile.is_open()){
		 string token,line;
		//first line is headings line
		 int nFields=0;
		 if ( getline (inFile,line,'\n') ){
			 std::istringstream iss(line);
			 nFields=std::count(std::istreambuf_iterator<char>(iss),  std::istreambuf_iterator<char>(), '\t')+1;
			 for(int i=0;i<nProbs;i++) rProbs[i]=new T[nFields];	
		 }
		 int n=0;
   while ( getline (inFile,line,'\n') && n < nFields){
			 std::istringstream iss(line);
			 getline(iss, token, '\t'); //first column is title
			 int j=0;
			 while(getline(iss, token, '\t')){
			 	rProbs[j++][n]=(T) atof(token.c_str());
    }
    n++;
		 }		 
		 inFile.close();				
	 }
	 return(rProbs);	
	}	
template <class T> T calculate_sst(int sizeb, T *b,T *ones){      
 //calculate sst which is used to calculate the R2
  T bbar=dot(sizeb,b,ones)/(T)sizeb; //first column of A contains row of ones 
  T *temp=new T[sizeb];
  memmove(temp,b,sizeb*sizeof(T));
  axpy(sizeb,-bbar,ones,temp);
  T sst=dot(sizeb,temp,temp);
  delete[] temp;
  return(sst);
}
template <class T> T getR2_full(ModelIndices &modelIndices, T* ATA,int ATAldr, T* ATb,const T btb,T *R,int Rldr){
	//returns the R2 value of the fit
	//writes the cholesky decomposition to R (without the best fit coordinates);
 const int p=modelIndices.nModels+1; 
 //add 1 because of 1s column - this is the dimension of the square Cholesky submatrix
 //However we also add a column/row for (ATb,btb) vector - trick to get the ssq/n and betahats  
	memset(R,0,(p+1)*Rldr*sizeof(T));
 for (int i=0;i<p;i++){
			//column 0 corresponds to column of 1s in ATA and in Rarray
			//column n corresponds to variable n-1 -> add one to this to get corresponding column in ATA matrix (because of 1s col...)
			//last column will be vector b
			//rightmost diagonal will b btb
			//solving this gives betahat and ssq
		const int coli= (i)?  modelIndices.list[i-1]+1:0;
		T* const Rslice=R+(i*Rldr);
		T* const ATAslice=ATA+(coli*ATAldr);
		for (int j=0;j<=i;j++){
			const int colj= (j)? modelIndices.list[j-1]+1 : 0;
			Rslice[j]=ATAslice[colj];
		}
	}
	//last colum
	T* const b=R+(p*Rldr);
 for (int i=0;i<p;i++){
		const int col= (i)?  modelIndices.list[i-1]+1:0;
		b[i]=ATb[col];
	}
 b[p]=btb;
 potrf('U',p+1,R,p+1);
 T ssqn1= R[(p*Rldr)+p];
 return(ssqn1*ssqn1);
} 
template <class T> T getR2_up(ModelIndices &modelIndices,T* ATA,int ATAldr, T* ATb,const T btb,T *R,int Rldr){
	//first solve for new triangular matrix using trsv
	//then solve for R_orig using new matrix trsv
	//writes over extra column in R_orig
	T rho;
	const int nRows=modelIndices.nModels+1; //the modelIndices include the added model - add one to this because of 1's column
	const int nCols=nRows-1;
 const int modelCol=modelIndices.list[modelIndices.nModels-1]+1;

	//v last column of R
	T* const v=R+nCols*Rldr;
	T* const ATAslice=ATA+(ATAldr*modelCol);
	v[0]=ATAslice[0];//1s column term
	for(int i=1;i<nRows;i++){
		const int colj=modelIndices.list[i-1]+1;
		v[i]=ATAslice[colj];
	}
 
 T temp=v[nRows-1];
 //calculate new vector to add to matrix using triangular solver
 trsvutr(nCols,R,Rldr,v); 
 rho=dot(nCols,v,v); 
 v[nRows-1]=(temp-rho>0)? sqrt	(temp-rho): 0;
 
 //add new response vector as column
 T *w=new T[nCols+1];
 w[0]=ATb[0]; //for the column of ones
 for (int i = 0; i <nCols; i++){
		w[i+1]=ATb[modelIndices.list[i]+1];
	}
 //number of columns have increased by 1...
 trsvutr(nCols+1,R,Rldr,w);
 rho=dot(nCols+1,w,w);
 delete[] w;
 return(btb-rho);
}
template <class T> T getR2_down(int nRows,ModelIndices &modelIndices,T* ATb,const T btb,T *R, int Rldr, int dCol){	
	//dCol is deleted column number
	const int nCols=nRows-1;
 //retriangularize the rows starting at the jth row
 //two workspace vectors required to store c and s for givens transforms
 //we use last column for one of these vectors

 const int size=(nRows-dCol-1<nCols-dCol)?nRows-dCol-1:nCols-dCol;
 T c[size],s[size],v[nCols];
 qhqr(nRows-dCol,nCols-dCol,&(R[dCol*Rldr+dCol]),Rldr,c,s);

	//calculate response vector
 v[0]=ATb[0]; //corresponds to column of 1s
 int k=1;
 for (int i = 0; i <dCol-1; i++){ 
	 v[k++]=ATb[modelIndices.list[i]+1];
	} 
	for (int i = dCol; i <nCols; i++){
	 v[k++]=ATb[modelIndices.list[i]+1]; 
	}
	T rho;
	//back substitute to get residuals
 trsvutr(nCols,R,Rldr,v);
 rho=dot(nCols,v,v);
 return(btb-rho);  
}		

//extra routines for update/downdate
template <class T> void qhqr (int nRows,int nCols,T *R, int ldr,T *c,T *s){
 //c++ implmentation of routines from qrupdate 
 //same routine except the pointer stuff is all explicit
 if (nRows <1 || nCols == 0) return;
 T* Ri=R;//pointer to ith column start
 for(int i=0;i<nCols;i++){
  //apply stored rotations, column-wise
  T t = Ri[0];
  int ii=(i<nRows-1)? i : nRows-1;
  for (int j=0;j<ii;j++){
   Ri[j]=c[j]*t+s[j]*Ri[j+1];
   t=c[j]*Ri[j+1]-s[j]*t; 
		}      
  if (ii < nRows-1){
			lartg(&t,&(Ri[ii+1]),&(c[i]),&(s[i]),&(Ri[ii])); //calculates the rotations - blas rotg does not work 
   Ri[ii+1]=0;
		}
		else{
			Ri[ii]=t;
		}
		Ri+=ldr;
	}
}	

//wrappers for cblas routines -see predeclarations for description
void sqmm(int nRows,int nCols,float *A,int Aldr, float *ATA,int ATAldr){cblas_sgemm(CblasColMajor, CblasTrans, CblasNoTrans, nCols,nCols,nRows,1,A,Aldr,A,Aldr,0,ATA,ATAldr);}	
void sqmm(int nRows,int nCols,double *A,int Aldr, double *ATA,int ATAldr){cblas_dgemm(CblasColMajor, CblasTrans, CblasNoTrans, nCols,nCols,nRows,1,A,Aldr,A,Aldr,0,ATA,ATAldr);}
void sqmm(int nRows,int nCols,float *A,int Aldr, float *ATA,int ATAldr,int nThreads){
	openblas_set_num_threads(nThreads);
	cblas_sgemm(CblasColMajor, CblasTrans, CblasNoTrans, nCols,nCols,nRows,1,A,Aldr,A,Aldr,0,ATA,ATAldr);
	openblas_set_num_threads(1);
	}	
void sqmm(int nRows,int nCols,double *A,int Aldr, double *ATA,int ATAldr,int nThreads){
	openblas_set_num_threads(nThreads);
	cblas_dgemm(CblasColMajor, CblasTrans, CblasNoTrans, nCols,nCols,nRows,1,A,Aldr,A,Aldr,0,ATA,ATAldr);
	openblas_set_num_threads(1);
	}	
void mtrv(int nRows, int nCols, double *A, int Aldr, double *b, double *ATb){cblas_dgemv(CblasColMajor, CblasTrans, nRows,nCols,1,A,Aldr,b,1,0,ATb,1);}
void mtrv(int nRows, int nCols, float *A, int Aldr, float *b, float *ATb){cblas_sgemv(CblasColMajor, CblasTrans, nRows,nCols,1,A,Aldr,b,1,0,ATb,1);  }
void lartg (double* f, double* g, double* cs, double* sn, double* r){dlartg_(f,g,cs,sn,r);}	
void lartg (float* f, float* g, float* cs, float* sn, float* r){slartg_( f,  g,  cs,  sn,  r);}
double dot(int n,double *x,double *y){return(cblas_ddot(n,x,1,y,1));}
float dot(int n,float *x,float *y){return(cblas_sdot(n,x,1,y,1));}	
double axpy (int n,double a,double *x,double *y){cblas_daxpy(n,a,x,1,y,1);}	
float axpy (int n,float a,float *x,float *y){cblas_saxpy(n,a,x,1,y,1);}
void trsvutr(int n,float *R, int Rldr, float *v){cblas_strsv(CblasColMajor,CblasUpper,CblasTrans,CblasNonUnit,n,R,Rldr,v,1); }	
void trsvutr(int n,double *R, int Rldr, double *v){cblas_dtrsv(CblasColMajor,CblasUpper,CblasTrans,CblasNonUnit,n,R,Rldr,v,1); }
void potrf(char ul,int n,double *R,int Rldr){
 blasint m=n;
 blasint ldr=Rldr;
 blasint info;
 char uplo=ul;
 BLASFUNC(dpotrf)(&uplo, &m, R, &ldr, &info);
} 
void potrf(char ul ,int n,float *R,int Rldr){
 blasint m=n;
 blasint ldr=Rldr;
 blasint info;
 char uplo=ul;
 BLASFUNC(spotrf)(&uplo, &m, R, &ldr, &info);
}
//utility routines
template <class T> void print_array(T* array,int n,int stride){
	for(int i=0;i<n;i++){
		for (int j=0;j<n;j++){
		 cout << array[i+j*stride] <<'\t';
		}
		cout << endl;
	}	
}	
template <class T> void print_array(T* array,int n,int stride,char *format){
	for(int i=0;i<n;i++){
		for (int j=0;j<n;j++){
			fprintf(stdout,format,array[i+j*stride]);
		}
		cout << endl;
	}	
}
//these routines are necessary as overloading the = operator requires that both ModelIndices and Const/CompactIndices be predeclared which requires wrapper class or redoing this as shared/inherited classes
void copy_indices(ModelIndices &dest,const CompactModelIndices  &source){
	dest.nModels=source.nModels;
	if(source.nModels) memmove(dest.list,source.list,source.nModels*sizeof(int));
	memset(dest.index,0,dest.maxModels*sizeof(int));	
 for(int i=0;i<dest.nModels;i++) dest.index[dest.list[i]]=i+1;
 dest.hashValue=source.hashValue;
}	 

template <class T> T TimeSeriesValuesToResiduals(T *values, T *residuals,int nTimes,int nGroups){
	
	//given a set of time series replicates this performs the following
	//the mean at each time over all replicates with that time is calculated 
	//expression values at each time are transformed by subtracting the mean
	//a linear model is constructed for each vector of these values at time t from the values at t-1
	//i.e. values_t= A*values_t_previous + B;
	//returns the ssq/n
	
	//input is all values of a specific time value
	//assume all replicates have the same time unit
	//assume that all times are already pre-sorted - with first element being low
	
	//calculate means over replicate
	vector <T> sums;
	sums.resize(nTimes);
	for(int i=0;i<nTimes;i++)
	 sums[i]=0;

 const int nSamples=nGroups*nTimes;
	for(int i=0;i<nSamples;i++){
	 sums[i%nTimes]+=values[i];
	}
	for (int i=0;i<nTimes;i++){
	 sums[i]/= (T) nGroups;
 }
 
 //subtract means from values
 for(int i=0;i<nSamples;i++){
		values[i]-=sums[i%nTimes];
	}	

 //set up cholesky decomp  
 
 const int nRows =nGroups*(nTimes-1);
 
	T *A=new T [2*nRows];
	T ATA[4];//2x2 matrix
	T R[9];//3x3 matrix 
	T *b=new T[nRows];
 const int ATAldr=2;
 const int Aldr=nRows;
 
 //set up data matrix
 //columnmajor so columns first...
 //first column is 1's 
 for (int i=0;i<nRows;i++)A[i]=1;	 
 for (int i=nRows;i<2*nRows;i++)A[i]=values[i-nRows];
 //set up response vector i.e. values at time t
 for (int i=0;i<nRows;i++)b[i]=values[i+nGroups];
 
	//square the data matrix;
	sqmm(nRows,2,A,Aldr,ATA,ATAldr,1); 
	
	T ATb[2];
	
	mtrv(nRows,2,A,Aldr,b,ATb);
 T btb=dot(nRows,b,b);
	
	//copy ATA to R matrix for Cholesky with last column ATb and btb which will be transformed into ATbeta and b*b
	R[0]=ATA[0];
	R[1]=ATA[1];
	R[2]=0;
	R[3]=ATA[2];
	R[4]=ATA[3];
	R[5]=0;
	R[6]=ATb[0]; //betahat for first column of ones i.e. the intercept
	R[7]=ATb[1]; //betahat for second column - values - i.e. the slope
	R[8]=btb;

 potrf('U',3,R,3);


 //back substitute to get residuals
 trsvutr(2,R,3,R+6);

 
 const T slope=R[7];
 const T intercept=R[6];
 for (int i=0;i<nRows;i++){
	 residuals[i]=values[i+nGroups]-values[i]*slope-intercept;
	}
	delete [] A;
	delete [] b;
	return(R[8]);	
}












