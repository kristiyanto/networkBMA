fastBMA <- function( x,
					 nTimePoints,
                     prior.probs = NULL,
                     g=ncol(x),
                     genenames=genenames,
                     verbose = FALSE,
                     geneIndex = NULL,
                     maxreg = NULL,
                     control = fastBMAcontrol()){
  #cl <- match.call();
  #print("fastBMA inner algorithm:")
  #print(genenames)
  
  if (is.null(geneIndex)) {
    y <- x[ ,1]
  } else {
    y <- x[ ,geneIndex]
  }
  
  
  ## For verbose mode, so don't have to check every time
  vprint <- function(...){}
  if ( verbose ) {
    vprint <- function(...){print(...)}
  }
  
  # null s or 1 prior.probs
  if ( is.null(prior.probs) ) {
    prior.probs <- matrix(2.76/6000.0, ncol(x), ncol(x));
  }
  if ( length(prior.probs) == 1 ) {
    prior.probs <- matrix(prior.probs, ncol(x), ncol(x));
  }
  eps <- 1e-8;
  prior.probs = pmin( pmax( prior.probs, eps ), 1 - eps );

  #null genenames
  if (is.null(genenames)) {
    genenames <- paste("X", 1:ncol(x), sep = "")
  }
  
  nvar <- ncol(x);

  #cpp call fast BMA
  vprint( "Running fastBMA..." );
  #print( "Running fastBMA..." );
  
  if (is.null(geneIndex)) geneIndex <- -1
  optimizeBit <- control$optimize

  #print(dim(x))
  #print(dim(prior.probs))
  #print(length(control$OR))
  #print(length(g))
  #print(length(genenames))
  #print(length(control$nThreads))
  #print(geneIndex)
  #print(length(optimizeBit))
  #print(length(control$gCtrl$iterlim))
  #print(length(control$timeSeries))
  #print(length(control$noPrune))
  #print(length(control$edgeMin))
  #print(length(control$edgeTol))
  
  rcpp.results <- fastBMA_g(x, nTimePoints, prior.probs,
                            control$OR, g,
                            genenames, control$nThreads,
                            geneIndex, optimizeBit,
                            control$iterlim,
                            control$timeSeries, control$noPrune,
                            control$edgeMin, control$edgeTol)
  
  #print( "done fastBMA..." );
  modelR2s <- round(rcpp.results$r2, 3);
  modelBICs <- rcpp.results$bic;
  n.models <- rcpp.results$n.models;
  size <- rcpp.results$size;
  

  result <- list(postprob = NULL, 
                 namesx = NULL,
                 label = NULL, 
                 r2 = NULL, 
                 bic = NULL, 
                 size = NULL, 
                 which = NULL, 
                 probne0 = NULL, 
                 postmean = NULL, 
                 postsd = NULL, 
                 condpostmean = NULL, 
                 condpostsd = NULL, 
                 ols = NULL, 
                 mle = NULL, 
                 se = NULL, 
                 reduced = FALSE, 
                 dropped = NULL, 
                 call = NULL, 
                 n.models = n.models,
                 n.vars = 0,
                 nmodelschecked = rcpp.results$nmodelschecked);
  if (n.models != 0) {
	which <- as.matrix(rcpp.results$which == 1);
	dimnames(which) <- list(NULL, genenames);
  
    labels <- apply(which, 1, function(x){paste(genenames[x], collapse="");});
    
    # Calculate Posterior Probabilities
    postprob <- rcpp.results$postprob;
    
    # Probability not equal to zero
    probne0 <- round(rcpp.results$probne0, 5);
    names(probne0) <- genenames;
    
    ##############
    nmod <- n.models;
    label <- labels;
    bic <- modelBICs;
    # Copied straight from bicreg
    model.fits <- as.list(rep(0, nmod))
    for (k in (1:nmod)) {
      if (sum(which[k, ]) != 0) {
        model.fits[[k]] <- ls.print(lsfit(x[, which[k, ], 
                                            drop = FALSE], y), print.it = FALSE)$coef.table[[1]]
      }
      else model.fits[[k]] <- ls.print(lsfit(rep(1, length(y)), 
                                             y, intercept = FALSE), print.it = FALSE)$coef.table[[1]]
    }
    Ebi <- rep(0, (nvar + 1))
    SDbi <- rep(0, (nvar + 1))
    CEbi <- Ebi
    CSDbi <- SDbi
    EbiMk <- matrix(rep(0, nmod * (nvar + 1)), nrow = nmod)
    sebiMk <- matrix(rep(0, nmod * (nvar + 1)), nrow = nmod)
    for (i in 1:(nvar + 1)) {
      if ((i == 1) || (sum(which[, (i - 1)] != 0))) {
        for (k in (1:nmod)) {
          if ((i == 1) || (which[k, (i - 1)] == TRUE)) {
            if (i == 1) 
              pos <- 1
            else pos <- 1 + sum(which[k, (1:(i - 1))])
            EbiMk[k, i] <- model.fits[[k]][pos, 1]
            sebiMk[k, i] <- model.fits[[k]][pos, 2]
          }
        }
        Ebi[i] <- as.numeric(sum(postprob * EbiMk[, i]))
        SDbi[i] <- sqrt(postprob %*% (sebiMk[, i]^2) + postprob %*% 
                          ((EbiMk[, i] - Ebi[i])^2))
        if (i == 1) {
          CEbi[i] <- Ebi[i]
          CSDbi[i] <- SDbi[i]
        }
        else {
          sel <- which[, i - 1]
          cpp <- postprob[sel]/sum(postprob[sel])
          CEbi[i] <- as.numeric(sum(cpp * EbiMk[sel, i]))
          CSDbi[i] <- sqrt(cpp %*% (sebiMk[sel, i]^2) + 
                             cpp %*% ((EbiMk[sel, i] - CEbi[i])^2))
        }
      }
    }
    dimnames(EbiMk) <- dimnames(sebiMk) <- list(NULL, c("Int", 
                                                        dimnames(x)[[2]]))
    ##############
    
    result <- list(postprob = postprob, 
                   namesx = genenames,
                   label = labels, 
                   r2 = modelR2s, 
                   bic = modelBICs, 
                   size = size, 
                   which = which, 
                   probne0 = c(probne0), 
                   postmean = Ebi, 
                   postsd = SDbi, 
                   condpostmean = CEbi, 
                   condpostsd = CSDbi, 
                   ols = EbiMk, 
                   mle = EbiMk, 
                   se = sebiMk, 
                   reduced = FALSE, 
                   dropped = NULL, 
                   #call = cl, 
                   n.models = n.models,
                   n.vars = length(probne0),
                   nmodelschecked = rcpp.results$nmodelschecked
    );
  }
  
  
  class(result) <- c("ScanBMA","bicreg");
  
  
  vprint( "Done" );
  
  if (geneIndex == -1) {
    
    edgeWeights <- rcpp.results$edgeWeights
    nParents <- rcpp.results$nParents
    parents <- rcpp.results$parents+1
	
	#print("edgeWeights")
	#print(edgeWeights)
	#print("nParents")
	#print(nParents)
	#print("parents")
	#print(parents)
	
	edgeList <- list()
    indexCounter <- 1
	
	#print("edgeWeights")
	#print(edgeWeights)
	#print("nParents")
	#print(nParents)
	#print("parents")
    #print(parents)
    
    for (i in 1:length(nParents)) {
	  if(nParents[i] != 0) {
		tmpWeight <- edgeWeights[indexCounter:(indexCounter+nParents[i]-1)]
		tmpParentsInd <- parents[indexCounter:(indexCounter+nParents[i]-1)]
		tmpParents <- genenames[tmpParentsInd]
		#print("tmpWeight")
		#print(tmpWeight)
		#print("tmpParentsInd")
		#print(tmpParentsInd)
		
		
		selectEdgeIndex <- (tmpWeight >= control$edgeMin) & (control$selfie | tmpParentsInd != i)
		#print("selectEdgeIndex")
		#print(selectEdgeIndex)
		tmpWeight <- tmpWeight[selectEdgeIndex]
		tmpParents <- tmpParents[selectEdgeIndex]
		
		names(tmpWeight) <- tmpParents
		indexCounter <- indexCounter + nParents[i];
		edgeList[[i]] <- tmpWeight
	  } else {
	    edgeList[[i]] <- NULL
	  }
	}
	names(edgeList) <- genenames
    
    return (edgeList)
    
  } else {
    return (result)
  }
  
}

