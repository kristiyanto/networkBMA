fastBMAcontrol <- function(OR = 10000,
                           optimize = 0,
						   iterlim = 20,
                           timeSeries = TRUE,
                           noPrune = FALSE,
                           edgeMin = 0.5,
                           edgeTol = -1,
                           nThreads = 1,
						   selfie = FALSE) { 
  
  list( algorithm = "fastBMA", OR = OR, optimize = optimize,
  iterlim = iterlim, timeSeries=timeSeries, noPrune = noPrune,
  edgeMin = edgeMin, edgeTol = edgeTol, nThreads = nThreads, selfie = selfie);
  
}